import numpy as np, pandas as pd, pickle, json, hashlib, platform, scipy, sys
F = pickle.load(open('final_fit_v4.pkl', 'rb')); D = pd.read_csv('model_diag_v4.csv'); SE = pd.read_csv('s3_se_2002_2015.csv'); SE = SE[SE.state_abbr != 'DC']
P = pd.read_csv('out/S3_Volunteering_Community_Activity_CANONICAL_RAW_v2.csv', dtype={'state_fips': str}); ST = sorted(P.state_abbr.unique())
N = pd.read_csv('out/S3_CPS_NATIONAL_BENCHMARK_v2.csv'); OB = pd.read_csv('S3_OFFICIAL_SE_2017_2023_v4.csv').set_index(['year','state_abbr']).se_official_replicate
set_ = SE.set_index(['year', 'state_abbr'])
rows = []
for _, r in P.iterrows():
    t, s = r.year - 2000, ST.index(r.state_abbr); lat, lse = F['S'][t, s], np.sqrt(F['tot_var'][t, s])
    if r.status == 'OBSERVED' and r.measurement_series == 'A_2002_2015':
        e = set_.loc[(r.year, r.state_abbr)]; obs_se = e.se_rep if not np.isnan(e.se_rep) else e.se_gvf
        sem = 'DIRECT_REPLICATE_SDR_160_REPS' if not np.isnan(e.se_rep) else 'GVF_OFFICIAL_S&A_PARAM_b_NATIONAL'; cls = 'DIRECT_OBSERVED'; reg = 'A_CPS_VOLUNTEER_2002_2015'
    elif r.status == 'OBSERVED':
        obs_se, sem, cls, reg = OB.loc[(r.year, r.state_abbr)], 'DIRECT_REPLICATE_SDR_160_REPS (official CEV nrrep)', 'DIRECT_OBSERVED', 'B_CPS_CEV_2017_2023'
    else:
        obs_se, sem, reg = np.nan, '', ('NONE_PRE_SURVEY' if r.year < 2002 else ('A_B_TRANSITION' if r.year == 2016 else 'B_CPS_CEV_2017_2023'))
        cls = 'MODEL_ESTIMATED_BACKCAST_NO_DATA' if r.year < 2002 else 'MODEL_ESTIMATED_BETWEEN_WAVES'
    rows.append(dict(S_variable='S3', year=r.year, state_fips=r.state_fips, state_abbr=r.state_abbr, state_name=r.state_name, observation_class=cls, survey_regime=reg,
        value_observed=r.value, value_observed_se=obs_se, value_observed_se_method=sem, S3_latent=lat, S3_latent_se=lse, S3_latent_lower95=lat - 1.96 * lse, S3_latent_upper95=lat + 1.96 * lse,
        latent_scale='CPS Volunteer Supplement 2002-2015 proportion scale (series A anchor)', S3_analytic=lat, S3_analytic_source='MODEL_SMOOTHED_LATENT (all cells; observed values preserved in value_observed)',
        source=r.source, source_file=r.source_file, provenance_status=r.provenance_status, interpolation='NONE'))
A = pd.DataFrame(rows); A.to_csv('v4/S3_Volunteering_Community_Activity_ANALYTICAL_FINAL_v4.csv', index=False)
# QA
chk = A.merge(P[['year', 'state_abbr', 'value']], on=['year', 'state_abbr']); unchanged = bool(np.allclose(chk.value_observed.fillna(-9), chk.value.fillna(-9), atol=0, rtol=0))
qa = dict(rows=len(A), states=A.state_abbr.nunique(), years=[int(A.year.min()), int(A.year.max()), int(A.year.nunique())], duplicates=int(A.duplicated(['year', 'state_abbr']).sum()),
          direct_observed=int((A.observation_class == 'DIRECT_OBSERVED').sum()), model_estimated=int(A.observation_class.str.startswith('MODEL').sum()), observed_values_unchanged_vs_v2=unchanged,
          latent_se_missing=int(A.S3_latent_se.isna().sum()), latent_range=[float(A.S3_latent.min()), float(A.S3_latent.max())], interpolation='NONE')
print(qa)
cov = A.groupby('year').apply(lambda g: pd.Series(dict(direct_observed=int((g.observation_class == 'DIRECT_OBSERVED').sum()), model_estimated=int(g.observation_class.str.startswith('MODEL').sum()),
      observation_class=g.observation_class.iloc[0], survey_regime=g.survey_regime.iloc[0], se_method=g.value_observed_se_method.iloc[0], mean_latent=g.S3_latent.mean(), mean_latent_se=g.S3_latent_se.mean(), duplicates=int(g.duplicated('state_abbr').sum())))).reset_index()
cov.to_csv('v4/S3_OBSERVATION_COVERAGE_v4.csv', index=False)
z, se = F['z'], F['se']; nm = F['names']
brk = pd.DataFrame([
 dict(item='regime A', value='CPS September Volunteer Supplement 2002-2015; volunteer = PES1 or PES2 follow-up prompt; universe 16+ civilian (supplement asked 15+)', evidence='Census codebooks; BLS technical note', status='VERIFIED'),
 dict(item='regime B', value='CPS Civic Engagement & Volunteering (CEV) 2017-2023, biennial; merged Volunteer + Civic Engagement supplements; content shifted; universe 16+', evidence='IPUMS CPS volunteer sample notes; Census working paper on 2017 CEV cognitive pretesting; AmeriCorps CEV pages', status='VERIFIED'),
 dict(item='official warning', value='BLS MLR (2020) attributes the national rise 24.9% (2015) -> 30.3% (2017) to the questionnaire change, not a behavioural change', evidence='BLS Monthly Labor Review 2020, "Making volunteer work visible"', status='VERIFIED'),
 dict(item='overlap year', value='NONE (2016 no supplement; no year fielded under both designs)', evidence='Census volunteer series listing', status='VERIFIED'),
 dict(item='option A (separate regimes in measurement eq.)', value='ADOPTED: series B has own intercept aB, loading lB, error tauB; series A anchored (a=0, l=1)', evidence='S1 v34.1 partial-invariance design', status='ADOPTED'),
 dict(item='option B (bridge via overlap/external benchmark)', value='NOT IDENTIFIABLE: no overlap wave and no external state-level benchmark measured under both designs', evidence='search of Census/BLS/AmeriCorps/SCCBS', status='REJECTED'),
 dict(item='option C (break dummy / series-specific params)', value='Equivalent to adopted A (aB is the break intercept)', evidence='', status='MERGED_WITH_A'),
 dict(item='aB (break intercept)', value=f'{z[3]:.4f} (SE {se[3]:.4f})', evidence='M2 MLE, Hessian SE', status='ESTIMATED'),
 dict(item='lB (break loading)', value=f'{z[4]:.4f} (SE {se[4]:.4f})', evidence='cross-state scale preserved (lB ~ 1)', status='ESTIMATED'),
 dict(item='BLS national benchmark of break size', value='+5.4 pp (24.9 -> 30.3)', evidence='BLS MLR 2020', status='CONSISTENT with aB = +5.8 pp'),
 dict(item='identification caveat', value='National level change between 2015 and 2017 is NOT separately identified from aB; the model attributes it to the design break subject to the national random-walk prior. Cross-state differences and within-regime changes are identified.', evidence='structural', status='LIMITATION'),
 dict(item='rescaling of observed values', value='NONE (observed values untouched; bridging only in measurement equation)', evidence='QA', status='DONE')])
brk.to_csv('v4/S3_MEASUREMENT_BREAK_ANALYSIS_v4.csv', index=False)
D2 = D.copy(); D2['selected'] = D2.model.str.startswith('M2')
fin = dict(model='M2_FINAL_tauA_fixed0 (selected)', loglik=F['ll'], k=7, AIC=-2 * F['ll'] + 14, converged=True, grad_max=F['grad'], hessian_min_eig=F['mineig'], hessian_pd=bool(F['mineig'] > 0),
           note=f"tau_A at boundary in free fit (3.6e-5); fixed 0 as in S1 v34.1; loglik free={F['ll_free']:.4f} vs fixed={F['ll']:.4f} (LR~0)", selected=True,
           **{n: v for n, v in zip(nm, z)}, **{f'{n}_se': v for n, v in zip(nm, se)})
M3 = dict(model='M3_BAYESIAN_NUTS', note='NOT EXECUTED; parameter uncertainty propagated instead by 300 draws from N(theta_hat, H^-1) (asymptotic approximation)', selected=False)
pd.concat([D2, pd.DataFrame([fin, M3])], ignore_index=True).to_csv('v4/S3_MODEL_METHOD_AND_DIAGNOSTICS_v4.csv', index=False)
src = json.load(open('s3_cps_sources.json')); raw = []
for s in src: raw.append(dict(file=s['zip_file'], sha256=s['zip_sha256'], data_member=s['data_member'], data_sha256=s['data_sha256'], url=('https://data.nber.org/cps/cpssep%s.zip' % str(s['year'])[2:] if s['year'] <= 2009 else 'https://www2.census.gov/programs-surveys/cps/datasets/%d/supp/sep%spub.zip' % (s['year'], str(s['year'])[2:]))))
import glob
for f in sorted(glob.glob('raw/sep1?nrrep.zip')): raw.append(dict(file=f.split('/')[-1], sha256=hashlib.sha256(open(f, 'rb').read()).hexdigest(), data_member='', data_sha256='', url='https://www2.census.gov/programs-surveys/cps/datasets/20%s/supp/%s' % (f[-12:-10], f.split('/')[-1])))
pd.DataFrame(raw).to_csv('v4/S3_RAW_SOURCE_MANIFEST_v4.csv', index=False)
log = pd.read_csv('out/S3_PROVENANCE_DECISION_LOG_v2.csv')
add = pd.DataFrame([
 dict(item='2000-2001 re-search', decision='No direct observation', evidence='CPS supplement began Sept 2002; SCCBS 2000 = national sample + 41 communities in 29 states (not 50-state comparable); Independent Sector surveys national only', status='MODEL_ESTIMATED_BACKCAST'),
 dict(item='2016/2018/2020/2022 re-search', decision='No direct observation', evidence='Census volunteer series lists 2015, then CEV 2017/2019/2021/2023 only; AmeriCorps CEV biennial', status='MODEL_ESTIMATED_BETWEEN_WAVES'),
 dict(item='SE 2011-2015', decision='Design-based SE from 160 successive-difference replicate weights, Var = 4/160*sum(theta_r - theta_0)^2', evidence='sepYYnrrep files; replicate 0 reproduces main estimate (max diff 8e-17); all persons matched', status='DONE'),
 dict(item='SE 2002-2010', decision='Official GVF: SE(p)=sqrt(b/y*p(1-p)), b=4,687 (volunteer Total 16+, Total/White), y=state weighted 16+ population', evidence='S&A Table C/4 each year; no state factor table found; GVF/replicate median ratio 0.91 in 2011-2015', status='DONE_WITH_CAVEAT'),
 dict(item='SE 2017-2023 (series B)', decision='OFFICIAL: 160 replicate weights (PWNRWGT replicates), Var=4/160*sum(theta_r-theta_0)^2; variable PES16==1 or PES16A==1, universe 16+ PRSUPINT==1', evidence='Census sep17/19 rep + sep21/23 nrrep; published AmeriCorps rates reproduced (max |diff| 4.9e-8)', status='DONE'),
 dict(item='SRS SE', decision='Retired from v3 (kept only in v2 as se_srs_approx; design effect ~1.34)', evidence='replicate/SRS median ratio 1.34', status='DONE'),
 dict(item='model selection', decision='M2 (national RW + state RW, series-specific measurement) over M1 (independent state RW): AIC -4180 vs -3964; M1 Hessian not PD', evidence='S3_MODEL_METHOD_AND_DIAGNOSTICS_v4.csv', status='DONE'),
 dict(item='holdout validation', decision='M2 95% coverage: 2013 1.00, 2009 1.00, 2002-03 backcast 0.99, 2017 0.98, 2019 0.84 (under-coverage in regime B interior)', evidence='diagnostics file', status='PARTIAL_WEAKNESS_REGIME_B')])
pd.concat([log, add], ignore_index=True).to_csv('v4/S3_PROVENANCE_DECISION_LOG_v4.csv', index=False)
open('v4/ENVIRONMENT_v4.txt', 'w').write(f"python {platform.python_version()}\nnumpy {np.__version__}\npandas {pd.__version__}\nscipy {scipy.__version__}\nplatform {platform.platform()}\nseed 20260930\n")
json.dump(qa, open('v4/QA_v4.json', 'w'), indent=1)
