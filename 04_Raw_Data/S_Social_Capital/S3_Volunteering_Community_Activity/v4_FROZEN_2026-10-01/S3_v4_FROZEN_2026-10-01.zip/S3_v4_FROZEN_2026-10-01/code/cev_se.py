import subprocess, numpy as np, pandas as pd, hashlib, json, datetime
V1 = pd.read_csv('../S3_Volunteering_Community_Activity_CEV_2017_2023_RAW_v1.csv')
FIPS = {1:'AL',2:'AK',4:'AZ',5:'AR',6:'CA',8:'CO',9:'CT',10:'DE',11:'DC',12:'FL',13:'GA',15:'HI',16:'ID',17:'IL',18:'IN',19:'IA',20:'KS',21:'KY',22:'LA',23:'ME',24:'MD',25:'MA',26:'MI',27:'MN',28:'MS',29:'MO',30:'MT',31:'NE',32:'NV',33:'NH',34:'NJ',35:'NM',36:'NY',37:'NC',38:'ND',39:'OH',40:'OK',41:'OR',42:'PA',44:'RI',45:'SC',46:'SD',47:'TN',48:'TX',49:'UT',50:'VT',51:'VA',53:'WA',54:'WV',55:'WI',56:'WY'}
def dat_main(zf, pos, minlen=1107):
    mem = subprocess.run(['unzip','-Z1',zf],capture_output=True,text=True).stdout.split()[0]
    L = subprocess.run(['unzip','-p',zf,mem],capture_output=True).stdout.decode('latin-1').splitlines()
    return pd.DataFrame([[l[a-1:b] for a,b in pos.values()] for l in L if len(l) >= minlen], columns=list(pos)).apply(lambda s: pd.to_numeric(s.str.strip(), errors='coerce'))
def dat_rep(zf):
    mem = subprocess.run(['unzip','-Z1',zf],capture_output=True,text=True).stdout.split()[0]
    L = subprocess.run(['unzip','-p',zf,mem],capture_output=True).stdout.decode('latin-1').splitlines()
    R = pd.DataFrame([[float(l[7+10*k:17+10*k]) for k in range(161)] for l in L], columns=[f'r{k}' for k in range(161)]) / 1e4
    R['QSTNUM'] = [int(l[0:5]) for l in L]; R['OCCURNUM'] = [int(l[5:7]) for l in L]; return R
out, nat, meta = [], [], []
for y in (2017, 2019, 2021, 2023):
    if y == 2017:
        d = dat_main('sep17pub.zip', dict(GESTFIPS=(93,94), PRTAGE=(122,123), PRPERTYP=(161,162), QSTNUM=(815,819), OCCURNUM=(820,821), PES16=(1035,1036), PES16A=(1037,1038), PRSUPINT=(1092,1093), PWNRWGT=(1098,1107)))
        d['PWNRWGT'] /= 1e4; R = dat_rep('sep17rep.zip'); src = ['sep17pub.zip', 'sep17rep.zip']
    else:
        cols = ['GESTFIPS','PRTAGE','PRPERTYP','QSTNUM','OCCURNUM','PES16','PES16A','PRSUPINT','PWNRWGT']
        if y != 2019: d = pd.read_csv(f'sep{str(y)[2:]}pub.csv', usecols=lambda c: c.upper() in cols); d.columns = [c.upper() for c in d.columns]
        if y == 2019:
            d = dat_main('sep19pub.zip', dict(GESTFIPS=(93,94), PRTAGE=(122,123), PRPERTYP=(161,162), QSTNUM=(815,819), OCCURNUM=(820,821), PES16=(1029,1030), PES16A=(1031,1032), PRSUPINT=(1042,1043), PWNRWGT=(1048,1057)), 1057)
            d['PWNRWGT'] /= 1e4; R = dat_rep('sep19rep.zip'); src = ['sep19pub.zip', 'sep19rep.zip']
        else:
            R = pd.read_csv(f'sep{str(y)[2:]}nrrep.csv'); R.columns = [c.upper() for c in R.columns]
            R = R.rename(columns={f'PWNRWGT{k}': f'r{k}' for k in range(161)}); src = [f'sep{str(y)[2:]}pub.csv', f'sep{str(y)[2:]}nrrep.csv']
            if R['r0'].sum() > 1e10: R[[f'r{k}' for k in range(161)]] /= 1e4
    if d.PWNRWGT.sum() > 1e10: d['PWNRWGT'] /= 1e4
    u = d[(d.PRPERTYP == 2) & (d.PRTAGE >= 16) & (d.PRSUPINT == 1)].copy()
    u['v_main'] = (u.PES16 == 1).astype(float); u['v_follow'] = ((u.PES16 == 1) | (u.PES16A == 1)).astype(float)
    m = u.merge(R, on=['QSTNUM', 'OCCURNUM'], how='left'); unmatched = int(m.r0.isna().sum())
    pub = V1[V1.year == y].set_index('state_abbr').value
    for var in ('v_main', 'v_follow'):
        est = m.groupby('GESTFIPS').apply(lambda g: (g[var] * g.PWNRWGT).sum() / g.PWNRWGT.sum()); est.index = est.index.map(FIPS); est = est.drop('DC')
        nat.append(dict(year=y, definition=var, national=float((u[var] * u.PWNRWGT).sum() / u.PWNRWGT.sum()), mae_vs_published=float((est - pub).abs().mean()), max_abs_vs_published=float((est - pub).abs().max())))
    var = min(('v_main', 'v_follow'), key=lambda v: [n for n in nat if n['year'] == y and n['definition'] == v][0]['mae_vs_published'])
    for f, g in m.groupby('GESTFIPS'):
        st = FIPS[int(f)]
        if st == 'DC': continue
        W = g[[f'r{k}' for k in range(161)]].values; vv = g[var].values[:, None]; th = (W * vv).sum(0) / W.sum(0)
        p = (g[var] * g.PWNRWGT).sum() / g.PWNRWGT.sum()
        out.append(dict(year=y, state_abbr=st, definition=var, n_unweighted=len(g), p_reproduced=p, p_rep0=th[0], se_official_replicate=np.sqrt(4 / 160 * np.sum((th[1:] - th[0]) ** 2)),
                        published_value_v1=pub[st], diff_vs_published=p - pub[st]))
    meta.append(dict(year=y, files=src, sha256=[hashlib.sha256(open(s, 'rb').read()).hexdigest() for s in src], variable=f'{var}: ' + ('PES16==1' if var == 'v_main' else 'PES16==1 or PES16A==1'),
                     universe='PRPERTYP==2 & PRTAGE>=16 & PRSUPINT==1', weight='PWNRWGT', replicate='160 replicates repwgt1..160 (repwgt0 = full sample)', formula='Var = 4/160 * sum_r (theta_r - theta_0)^2', unmatched=unmatched))
    print(y, var, unmatched, flush=True)
pd.DataFrame(out).to_csv('S3_OFFICIAL_SE_2017_2023_v4.csv', index=False); pd.DataFrame(nat).to_csv('cev_definition_check.csv', index=False); json.dump(meta, open('cev_meta.json', 'w'), indent=1)
O = pd.DataFrame(out); print(pd.DataFrame(nat).round(5).to_string()); print(O.groupby('year').agg(maxdiff=('diff_vs_published', lambda x: x.abs().max()), rep0diff=('p_rep0', 'mean'), med_se=('se_official_replicate', 'median'), n=('state_abbr', 'size')))
print('rep0 vs point max', (O.p_rep0 - O.p_reproduced).abs().max())
