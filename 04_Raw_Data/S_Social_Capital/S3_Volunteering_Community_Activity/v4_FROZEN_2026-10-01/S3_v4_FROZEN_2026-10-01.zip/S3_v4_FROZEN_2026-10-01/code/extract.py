import zipfile, io, hashlib, json, numpy as np, pandas as pd
L = {2002:(857,859,1030,1036), 2003:(877,879,1036,1042), 2004:(877,879,1038,1044), 2005:(951,953,1114,1120), 2006:(951,953,1124,1130),
     2007:(951,953,1136,1142), 2008:(951,953,1134,1140)}
for y in range(2009, 2016): L[y] = (951, 953, 1134, 1140)
FIPS = {1:'AL',2:'AK',4:'AZ',5:'AR',6:'CA',8:'CO',9:'CT',10:'DE',11:'DC',12:'FL',13:'GA',15:'HI',16:'ID',17:'IL',18:'IN',19:'IA',20:'KS',21:'KY',22:'LA',23:'ME',24:'MD',25:'MA',26:'MI',27:'MN',28:'MS',29:'MO',30:'MT',31:'NE',32:'NV',33:'NH',34:'NJ',35:'NM',36:'NY',37:'NC',38:'ND',39:'OH',40:'OK',41:'OR',42:'PA',44:'RI',45:'SC',46:'SD',47:'TN',48:'TX',49:'UT',50:'VT',51:'VA',53:'WA',54:'WV',55:'WI',56:'WY'}
rows, nat, src = [], [], []
for y, (p1, p2, sp, wp) in sorted(L.items()):
    zf = 'sep15pub.zip' if y == 2015 else f'sep{str(y)[2:]}.zip'
    import subprocess; dn = [l.split()[-1] for l in subprocess.run(['unzip','-Z1',zf],capture_output=True,text=True).stdout.split() if l and not l.endswith('/')]; assert len(dn) == 1, dn; raw = subprocess.run(['unzip','-p',zf,dn[0]],capture_output=True).stdout
    lines = raw.decode('latin-1').splitlines()
    cs = [(92, 94), (121, 123), (160, 162), (p1 - 1, p1 + 1), (p2 - 1, p2 + 1), (sp - 1, sp + 1), (wp - 1, wp + 9)]
    rec = [[l[a:b] for a, b in cs] for l in lines if len(l) >= wp + 9]
    d = pd.DataFrame(rec, columns=['st', 'age', 'ptyp', 'pes1', 'pes2', 'sup', 'w']).apply(lambda s: pd.to_numeric(s.str.strip(), errors='coerce'))
    u = d[(d.ptyp == 2) & (d.age >= 16) & (d.sup == 1)].copy(); u['w'] = u.w / 1e4; u['vol'] = ((u.pes1 == 1) | (u.pes2 == 1)).astype(float)
    bad = int(((u.pes1 == -1)).sum())
    nat.append(dict(year=y, records=len(d), universe_n=len(u), pes1_NIU_in_universe=bad, pop16_thousands=u.w.sum() / 1e3, volunteers_thousands=(u.vol * u.w).sum() / 1e3,
                    rate=(u.vol * u.w).sum() / u.w.sum(), dk_both_n=int(((u.pes1 == -2) & (u.pes2 != 1)).sum())))
    src.append(dict(year=y, zip_file=zf, zip_sha256=hashlib.sha256(open(zf, 'rb').read()).hexdigest(), data_member=dn[0], data_sha256=hashlib.sha256(raw).hexdigest(), n_lines=len(lines),
                    layout=dict(GESTFIPS='93-94', AGE='122-123', PRPERTYP='161-162', PES1=f'{p1}-{p1+1}', PES2=f'{p2}-{p2+1}', PRSUPINT=f'{sp}-{sp+1}', PWNRWGT=f'{wp}-{wp+9}')))
    for f, g in u.groupby('st'):
        p = (g.vol * g.w).sum() / g.w.sum(); n = len(g)
        rows.append(dict(year=y, state_fips=int(f), state_abbr=FIPS.get(int(f)), n_unweighted=n, weighted_pop=g.w.sum(), value=p, se_srs_approx=np.sqrt(p * (1 - p) / n)))
    print(nat[-1], flush=True)
pd.DataFrame(rows).to_csv('../s3_cps_state_rates_2002_2015.csv', index=False); pd.DataFrame(nat).to_csv('../s3_cps_national_2002_2015.csv', index=False)
json.dump(src, open('../s3_cps_sources.json', 'w'), indent=1)
