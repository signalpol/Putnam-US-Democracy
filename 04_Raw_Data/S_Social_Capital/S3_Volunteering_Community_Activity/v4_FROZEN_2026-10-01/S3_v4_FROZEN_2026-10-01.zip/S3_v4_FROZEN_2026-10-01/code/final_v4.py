import numpy as np, pandas as pd, pickle, json
exec(open('model_v4.py').read().split('res, diag = {}, []')[0])
d = pickle.load(open('model_fit_v4.pkl', 'rb')); x0 = d['res']['M2_HIER_NATIONAL_PLUS_STATE_RW']['x']
# tau_A at boundary -> fix tau_A = 0 (as in S1 v34.1) ; free params = all but index 3
FIX = -30.0
def full(z): return np.insert(z, 3, FIX)
f = lambda z: -kf(full(z), True, Y)
from scipy.optimize import minimize
z0 = np.delete(x0, 3); r = minimize(f, z0, method='BFGS', options=dict(gtol=1e-7, maxiter=2000))
z = r.x
for it in range(20):                                    # Newton polishing
    g = np.array([(f(z + np.eye(len(z))[i] * 1e-5) - f(z - np.eye(len(z))[i] * 1e-5)) / 2e-5 for i in range(len(z))])
    if np.abs(g).max() < 1e-3: break
    H = hess(f, z); z = z - np.linalg.solve(H, g)
H = hess(f, z); ev = np.linalg.eigvalsh(H); g = gradmax(f, z); cov = np.linalg.inv(H); se = np.sqrt(np.diag(cov))
names = ['m0', 'log_s0', 'log_qu', 'aB', 'lB', 'log_tB', 'log_qm']
LR = 2 * ((-f(z)) - kf(x0, True, Y))
print(dict(loglik=-f(z), loglik_free_tauA=kf(x0, True, Y), LR_tauA=-LR, grad_max=g, min_eig=ev.min(), converged=bool(r.success)))
print(pd.DataFrame(dict(param=names, est=z, se=se)).round(6).to_string())
# point smoothing + parameter-uncertainty draws
_, S, Sv = kf(full(z), True, Y, smooth=True)
draws = np.random.multivariate_normal(z, cov, 300); Sd, Vd = [], []
for dz in draws:
    _, s_, v_ = kf(full(dz), True, Y, smooth=True); Sd.append(s_); Vd.append(v_)
Sd, Vd = np.array(Sd), np.array(Vd); tot_var = Vd.mean(0) + Sd.var(0)
pickle.dump(dict(z=z, se=se, names=names, cov=cov, S=S, Sv=Sv, tot_var=tot_var, Smean=Sd.mean(0), grad=g, mineig=ev.min(), ll=-f(z), ll_free=kf(x0, True, Y)), open('final_fit_v4.pkl', 'wb'))
print('median cond SE', np.sqrt(Sv).mean(), 'median total SE', np.sqrt(tot_var).mean(), 'max |Smean-S|', np.abs(Sd.mean(0) - S).max())
for y in (2000, 2002, 2015, 2016, 2017, 2020, 2023): print(y, 'mean S', S[y - 2000].mean().round(4), 'mean SE', np.sqrt(tot_var[y - 2000]).mean().round(4))
