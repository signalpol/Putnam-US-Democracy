import pandas as pd, os, shutil
P = 'S3_v4_FROZEN_2026-10-01'
src = open('build_v4.py').read(); audit = []
for ln, line in enumerate(src.splitlines(), 1):
    if 'v3' in line:
        if 'ENVIRONMENT_v3.txt' in line or 'QA_v3.json' in line:
            audit.append(dict(line=ln, cls='B_STALE_LABEL', before=line.strip()[:140], after=line.replace('ENVIRONMENT_v3.txt', 'ENVIRONMENT_v4.txt').replace('QA_v3.json', 'QA_v4.json').strip()[:140], reason='output filename label in v4 run; filename only, no effect on computation'))
        else:
            audit.append(dict(line=ln, cls='A_LEGITIMATE_PROVENANCE', before=line.strip()[:140], after='(unchanged)', reason="substring of 'S1 v34.1' reference or historical note 'Retired from v3'"))
open(f'{P}/code/build_v4.py', 'w').write(src.replace('ENVIRONMENT_v3.txt', 'ENVIRONMENT_v4.txt').replace('QA_v3.json', 'QA_v4.json'))
pd.DataFrame(audit).rename(columns={'cls': 'class'}).to_csv(f'{P}/qa/S3_v4_BUILD_STRING_AUDIT.csv', index=False)
print(pd.DataFrame(audit)[['line', 'cls']].to_string(index=False))
shutil.copy('v4/ENVIRONMENT_v3.txt', f'{P}/code/ENVIRONMENT_v4.txt'); shutil.copy('v4/QA_v3.json', f'{P}/qa/QA_v4.json')
F = pd.read_csv('v4/S3_Volunteering_Community_Activity_ANALYTICAL_FINAL_v4.csv', dtype={'state_fips': str})
F['interval_undercoverage_risk'] = ((F.observation_class == 'MODEL_ESTIMATED_BETWEEN_WAVES') & F.year.isin([2018, 2020, 2022])).astype(int)
F.to_csv(f'{P}/data/S3_FINAL_v4.csv', index=False)
for f in ['S3_Volunteering_Community_Activity_ANALYTICAL_FINAL_v4.csv', 'S3_Volunteering_Community_Activity_CANONICAL_RAW_v2.csv', 'S3_OFFICIAL_SE_2017_2023_v4.csv', 'S3_CPS_NATIONAL_BENCHMARK_v2.csv', 'S3_OBSERVATION_COVERAGE_v4.csv']: shutil.copy('v4/' + f, f'{P}/data/')
shutil.copy('S3_Volunteering_Community_Activity_CEV_2017_2023_RAW_v1.csv', f'{P}/data/'); shutil.copy('s3_se_2002_2015.csv', f'{P}/data/S3_SE_2002_2015_v4.csv')
shutil.copy('s3_cps_state_rates_2002_2015.csv', f'{P}/data/'); shutil.copy('s3_cps_national_2002_2015.csv', f'{P}/data/'); shutil.copy('s3_cps_sources.json', f'{P}/provenance/')
for f in ['extract.py', 'se.py', 'model_v4.py', 'final_v4.py', 'model_v4b.py', 'freeze_v4.py']: shutil.copy(f, f'{P}/code/')
shutil.copy('cev/cev_se.py', f'{P}/code/')
shutil.copy('run_v4.log', f'{P}/logs/run_v4.log'); shutil.copy('cev/download_log.txt', f'{P}/logs/download_log_CEV.txt'); shutil.copy('cev/cev.log', f'{P}/logs/cev_se.log')
for f in ['se.log', 'model.log', 'final.log']:
    if os.path.exists(f): shutil.copy(f, f'{P}/logs/{f[:-4]}_v3era.log')
for f in ['S3_SOURCE_MANIFEST_v4.csv', 'S3_PROVENANCE_DECISION_LOG_v4.csv', 'S3_MEASUREMENT_BREAK_ANALYSIS_v4.csv']: shutil.copy('v4/' + f, f'{P}/provenance/')
shutil.copy('cev/cev_definition_check.csv', f'{P}/provenance/S3_CEV_DEFINITION_CHECK_v4.csv'); shutil.copy('cev/cev_meta.json', f'{P}/provenance/S3_CEV_SE_META_v4.json')
for f in ['S3_QA_v4.csv', 'S3_HOLDOUT_VALIDATION_v4.csv', 'S3_MODEL_DIAGNOSTICS_v4.csv', 'S3_MODEL_PARAMETERS_v4.csv']: shutil.copy('v4/' + f, f'{P}/qa/')
C = pd.read_csv(f'{P}/data/S3_Volunteering_Community_Activity_CANONICAL_RAW_v2.csv'); m = F.merge(C[['year', 'state_abbr', 'value']], on=['year', 'state_abbr'])
ok = lambda b: 'PASS' if bool(b) else 'FAIL'
Q = [('rows == 1200', len(F) == 1200), ('50 states, years 2000-2023', F.state_abbr.nunique() == 50 and sorted(F.year.unique()) == list(range(2000, 2024))),
     ('state-year duplicates == 0', F.duplicated(['year', 'state_abbr']).sum() == 0), ('direct == 900', (F.observation_class == 'DIRECT_OBSERVED').sum() == 900),
     ('model-estimated == 300 (200 between + 100 backcast)', (F.observation_class == 'MODEL_ESTIMATED_BETWEEN_WAVES').sum() == 200 and (F.observation_class == 'MODEL_ESTIMATED_BACKCAST_NO_DATA').sum() == 100),
     ('observed exact match canonical raw', ((m.value_observed == m.value) | (m.value_observed.isna() & m.value.isna())).all()),
     ('official SE direct coverage 900/900', F[F.observation_class == 'DIRECT_OBSERVED'].value_observed_se.notna().sum() == 900 and not F.value_observed_se_method.fillna('').str.contains('IMPUTED').any()),
     ('canonical estimate missing == 0', F.S3_latent.notna().all() and F.S3_latent_se.notna().all() and (F.S3_latent_se > 0).all()),
     ('interpolation / forward / backward fill == 0', (F.interpolation == 'NONE').all()),
     ('limitation flag == 150 (2018/2020/2022)', F.interval_undercoverage_risk.sum() == 150 and set(F[F.interval_undercoverage_risk == 1].year) == {2018, 2020, 2022}),
     ('state identifier validity', set(F.state_abbr) == set(C.state_abbr) and F.groupby('state_abbr').state_fips.nunique().max() == 1), ('year validity', F.year.between(2000, 2023).all()),
     ('source classification validity', set(F.observation_class) == {'DIRECT_OBSERVED', 'MODEL_ESTIMATED_BETWEEN_WAVES', 'MODEL_ESTIMATED_BACKCAST_NO_DATA'} and F[F.observation_class == 'DIRECT_OBSERVED'].survey_regime.isin(['A_CPS_VOLUNTEER_2002_2015', 'B_CPS_CEV_2017_2023']).all())]
prev = pd.read_csv('v4/S3_QA_v4.csv'); Qd = pd.DataFrame([dict(check=c, result=ok(v)) for c, v in Q])
Qd.loc[len(Qd)] = dict(check='previous v4 QA 10/10 PASS reproduced', result=ok((prev.result == 'PASS').all() and len(prev) == 10))
Qd.to_csv(f'{P}/qa/S3_FINAL_QA_FREEZE_v4.csv', index=False); print(Qd.to_string(index=False))
