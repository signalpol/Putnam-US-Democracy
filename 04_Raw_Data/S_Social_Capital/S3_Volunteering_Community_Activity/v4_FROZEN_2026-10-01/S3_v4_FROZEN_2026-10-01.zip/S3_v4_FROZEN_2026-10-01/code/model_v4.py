import numpy as np, pandas as pd, json
from scipy.optimize import minimize
np.random.seed(20260930)
P = pd.read_csv('out/S3_Volunteering_Community_Activity_CANONICAL_RAW_v2.csv', dtype={'state_fips': str})
SE = pd.read_csv('s3_se_2002_2015.csv'); SE = SE[SE.state_abbr != 'DC']
ST = sorted(P.state_abbr.unique()); YR = list(range(2000, 2024)); T, NS = 24, 50
se_tab = SE.assign(se_final=np.where(SE.se_rep.notna(), SE.se_rep, SE.se_gvf), se_method=np.where(SE.se_rep.notna(), 'DIRECT_REPLICATE_SDR_160', 'GVF_OFFICIAL_PARAM_b')).set_index(['year', 'state_abbr'])
OB = pd.read_csv('S3_OFFICIAL_SE_2017_2023_v4.csv').set_index(['year', 'state_abbr']).se_official_replicate   # official CEV replicate SE
Y = np.full((T, NS), np.nan); V = np.full((T, NS), np.nan); R = np.zeros(T, int)   # regime 0 none, 1 A, 2 B
for _, r in P[P.status == 'OBSERVED'].iterrows():
    t, s = r.year - 2000, ST.index(r.state_abbr); Y[t, s] = r.value
    if r.measurement_series == 'A_2002_2015': V[t, s] = se_tab.loc[(r.year, r.state_abbr), 'se_final'] ** 2; R[t] = 1
    else: V[t, s] = OB.loc[(r.year, r.state_abbr)] ** 2; R[t] = 2
def unpack(th, common):
    d = dict(m0=th[0], s0=np.exp(th[1]), qu=np.exp(th[2]), tA=np.exp(th[3]), aB=th[4], lB=th[5], tB=np.exp(th[6]))
    d['qm'] = np.exp(th[7]) if common else 0.0; return d
def kf(th, common, Yh, smooth=False):
    p = unpack(th, common); n = NS + 1
    x = np.zeros(n); x[0] = p['m0']; Pm = np.diag([0.0] + [p['s0'] ** 2] * NS); Q = np.diag([p['qm']] + [p['qu']] * NS)
    ll = 0.0; XF, PF, XP, PP = [], [], [], []
    for t in range(T):
        if t: Pm = Pm + Q
        XP.append(x.copy()); PP.append(Pm.copy())
        if R[t]:
            a, l, tau = (0.0, 1.0, p['tA']) if R[t] == 1 else (p['aB'], p['lB'], p['tB'])
            for s in range(NS):
                if np.isnan(Yh[t, s]): continue
                h = np.zeros(n); h[0] = l; h[s + 1] = l
                ph = Pm @ h; F = h @ ph + V[t, s] + tau ** 2; e = Yh[t, s] - a - h @ x
                ll += -0.5 * (np.log(2 * np.pi * F) + e * e / F); K = ph / F; x = x + K * e; Pm = Pm - np.outer(K, ph)
        XF.append(x.copy()); PF.append(Pm.copy())
    if not smooth: return ll
    xs, Ps = [None] * T, [None] * T; xs[-1], Ps[-1] = XF[-1], PF[-1]
    for t in range(T - 2, -1, -1):
        J = PF[t] @ np.linalg.pinv(PP[t + 1]); xs[t] = XF[t] + J @ (xs[t + 1] - XP[t + 1]); Ps[t] = PF[t] + J @ (Ps[t + 1] - PP[t + 1]) @ J.T
    Hs = np.hstack([np.ones((NS, 1)), np.eye(NS)])
    S = np.array([Hs @ xs[t] for t in range(T)]); Sv = np.array([np.einsum('ij,jk,ik->i', Hs, Ps[t], Hs) for t in range(T)])
    return ll, S, Sv
def fit(common, Yh, starts=4):
    best = None
    for k in range(starts):
        th0 = np.array([0.28, np.log(0.05), np.log(1e-4), np.log(0.01), 0.05, 1.0, np.log(0.02)] + ([np.log(1e-4)] if common else []))
        if k: th0 = th0 + np.random.normal(0, 0.3, len(th0))
        r = minimize(lambda th: -kf(th, common, Yh), th0, method='L-BFGS-B', options=dict(maxiter=500))
        if best is None or r.fun < best.fun: best = r
    return best
def hess(f, x, h=1e-4):
    k = len(x); H = np.zeros((k, k))
    for i in range(k):
        for j in range(i, k):
            e1, e2 = np.eye(k)[i] * h, np.eye(k)[j] * h
            H[i, j] = H[j, i] = (f(x + e1 + e2) - f(x + e1 - e2) - f(x - e1 + e2) + f(x - e1 - e2)) / (4 * h * h)
    return H
def gradmax(f, x, h=1e-5): return max(abs((f(x + np.eye(len(x))[i] * h) - f(x - np.eye(len(x))[i] * h)) / (2 * h)) for i in range(len(x)))
res, diag = {}, []
for name, common in (('M1_INDEP_STATE_RW', False), ('M2_HIER_NATIONAL_PLUS_STATE_RW', True)):
    r = fit(common, Y); f = lambda th: -kf(th, common, Y); H = hess(f, r.x); ev = np.linalg.eigvalsh(H)
    k = len(r.x); aic = 2 * r.fun + 2 * k
    # holdout validation
    hv = {}
    for label, yrs in (('HOLDOUT_2013_interior', [2013]), ('HOLDOUT_2009_interior', [2009]), ('HOLDOUT_2002_2003_backcast', [2002, 2003]), ('HOLDOUT_2019_regimeB_interior', [2019]), ('HOLDOUT_2017_first_B_wave', [2017])):
        Yh = Y.copy(); [Yh.__setitem__((y - 2000, slice(None)), np.nan) for y in yrs]
        rh = fit(common, Yh, starts=2); _, S, Sv = kf(rh.x, common, Yh, smooth=True); p = unpack(rh.x, common); err, cov = [], []
        for y in yrs:
            t = y - 2000; a, l, tau = (0.0, 1.0, p['tA']) if R[t] == 1 else (p['aB'], p['lB'], p['tB'])
            mu = a + l * S[t]; sd = np.sqrt(l * l * Sv[t] + V[t] + tau ** 2); z = (Y[t] - mu) / sd; err += list(Y[t] - mu); cov += list(np.abs(z) < 1.96)
        hv[label] = (float(np.sqrt(np.mean(np.square(err)))), float(np.mean(cov)))
    res[name] = dict(x=r.x, common=common, H=H)
    p = unpack(r.x, common)
    diag.append(dict(model=name, loglik=-r.fun, k=k, AIC=aic, converged=bool(r.success), grad_max=gradmax(f, r.x), hessian_min_eig=float(ev.min()), hessian_pd=bool(ev.min() > 0),
                     **{kk: float(v) for kk, v in p.items()}, **{f'{kk}_RMSE': v[0] for kk, v in hv.items()}, **{f'{kk}_cov95': v[1] for kk, v in hv.items()}))
    print(json.dumps(diag[-1], default=float), flush=True)
D = pd.DataFrame(diag); D.to_csv('model_diag_v4.csv', index=False)
import pickle; pickle.dump(dict(res=res, Y=Y, V=V, R=R, ST=ST), open('model_fit_v4.pkl', 'wb'))
