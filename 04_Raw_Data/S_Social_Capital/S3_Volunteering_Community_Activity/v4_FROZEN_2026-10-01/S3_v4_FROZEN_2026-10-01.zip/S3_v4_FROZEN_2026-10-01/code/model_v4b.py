# M2b = M2 + transitory national year shock c_t ~ N(0, sc^2), iid (e.g. COVID-type temporary common shocks)
import numpy as np, pandas as pd, json, pickle
from scipy.optimize import minimize
exec(open('model_v4.py').read().split('def unpack')[0])
def hess(f, x, h=1e-4):
    k = len(x); H = np.zeros((k, k))
    for i in range(k):
        for j in range(i, k):
            e1, e2 = np.eye(k)[i] * h, np.eye(k)[j] * h
            H[i, j] = H[j, i] = (f(x + e1 + e2) - f(x + e1 - e2) - f(x - e1 + e2) + f(x - e1 - e2)) / (4 * h * h)
    return H
def gradmax(f, x, h=1e-5): return max(abs((f(x + np.eye(len(x))[i] * h) - f(x - np.eye(len(x))[i] * h)) / (2 * h)) for i in range(len(x)))

NSD = NS + 2   # [mu, c, u_1..u_50]
def unpack(th): return dict(m0=th[0], s0=np.exp(th[1]), qu=np.exp(th[2]), tA=0.0, aB=th[3], lB=th[4], tB=np.exp(th[5]), qm=np.exp(th[6]), sc=np.exp(th[7]))
def kf(th, Yh, smooth=False):
    p = unpack(th); x = np.zeros(NSD); x[0] = p['m0']; Pm = np.diag([0.0, p['sc'] ** 2] + [p['s0'] ** 2] * NS)
    Fm = np.eye(NSD); Fm[1, 1] = 0.0; Q = np.diag([p['qm'], p['sc'] ** 2] + [p['qu']] * NS); ll = 0.0; XF, PF, XP, PP = [], [], [], []
    for t in range(T):
        if t: x = Fm @ x; Pm = Fm @ Pm @ Fm.T + Q
        XP.append(x.copy()); PP.append(Pm.copy())
        if R[t]:
            a, l, tau = (0.0, 1.0, 0.0) if R[t] == 1 else (p['aB'], p['lB'], p['tB'])
            for s in range(NS):
                if np.isnan(Yh[t, s]): continue
                h = np.zeros(NSD); h[0] = l; h[1] = l; h[s + 2] = l; ph = Pm @ h; Fv = h @ ph + V[t, s] + tau ** 2; e = Yh[t, s] - a - h @ x
                ll += -0.5 * (np.log(2 * np.pi * Fv) + e * e / Fv); K = ph / Fv; x = x + K * e; Pm = Pm - np.outer(K, ph)
        XF.append(x.copy()); PF.append(Pm.copy())
    if not smooth: return ll
    xs, Ps = [None] * T, [None] * T; xs[-1], Ps[-1] = XF[-1], PF[-1]
    for t in range(T - 2, -1, -1):
        J = PF[t] @ Fm.T @ np.linalg.pinv(PP[t + 1]); xs[t] = XF[t] + J @ (xs[t + 1] - XP[t + 1]); Ps[t] = PF[t] + J @ (Ps[t + 1] - PP[t + 1]) @ J.T
    Hs = np.hstack([np.ones((NS, 2)), np.eye(NS)])   # latent S3 includes transitory national shock
    return ll, np.array([Hs @ xs[t] for t in range(T)]), np.array([np.einsum('ij,jk,ik->i', Hs, Ps[t], Hs) for t in range(T)])
f0 = pickle.load(open('final_fit_v4.pkl', 'rb'))['z']   # M2 final [m0, ls0, lqu, aB, lB, ltB, lqm]
def fit(Yh, starts=3):
    best = None
    for k in range(starts):
        th0 = np.append(f0, np.log(0.01)) + (np.random.normal(0, 0.2, 8) if k else 0)
        r = minimize(lambda th: -kf(th, Yh), th0, method='L-BFGS-B', options=dict(maxiter=600))
        if best is None or r.fun < best.fun: best = r
    return best
r = fit(Y); z = r.x; f = lambda th: -kf(th, Y)
for it in range(20):
    g = np.array([(f(z + np.eye(8)[i] * 1e-5) - f(z - np.eye(8)[i] * 1e-5)) / 2e-5 for i in range(8)])
    if np.abs(g).max() < 1e-3: break
    z = z - np.linalg.solve(hess(f, z), g)
H = hess(f, z); ev = np.linalg.eigvalsh(H); cov = np.linalg.inv(H); se = np.sqrt(np.diag(cov)); gm = gradmax(f, z); ll = -f(z)
hv = {}
for label, yrs in (('HOLDOUT_2013_interior', [2013]), ('HOLDOUT_2009_interior', [2009]), ('HOLDOUT_2002_2003_backcast', [2002, 2003]), ('HOLDOUT_2019_regimeB_interior', [2019]), ('HOLDOUT_2017_first_B_wave', [2017])):
    Yh = Y.copy()
    for y in yrs: Yh[y - 2000] = np.nan
    rh = fit(Yh, 2); _, S, Sv = kf(rh.x, Yh, True); p = unpack(rh.x); err, cv = [], []
    for y in yrs:
        t = y - 2000; a, l, tau = (0.0, 1.0, 0.0) if R[t] == 1 else (p['aB'], p['lB'], p['tB'])
        mu = a + l * S[t]; sd = np.sqrt(l * l * Sv[t] + V[t] + tau ** 2); err += list(Y[t] - mu); cv += list(np.abs((Y[t] - mu) / sd) < 1.96)
    hv[label] = dict(RMSE=float(np.sqrt(np.mean(np.square(err)))), cov95=float(np.mean(cv)), mean_error=float(np.mean(err)))
_, S, Sv = kf(z, Y, True); Sd, Vd = [], []
for dz in np.random.multivariate_normal(z, cov, 300):
    _, s_, v_ = kf(dz, Y, True); Sd.append(s_); Vd.append(v_)
Sd, Vd = np.array(Sd), np.array(Vd); tot = Vd.mean(0) + Sd.var(0)
names = ['m0', 'log_s0', 'log_qu', 'aB', 'lB', 'log_tB', 'log_qm', 'log_sc']
res = dict(model='M2b_HIER_RW_PLUS_TRANSITORY_NATIONAL_SHOCK', loglik=ll, k=8, AIC=-2 * ll + 16, grad_max=gm, hessian_min_eig=float(ev.min()), hessian_pd=bool(ev.min() > 0), holdout=hv, params=dict(zip(names, map(float, z))), se=dict(zip(names, map(float, se))))
print(json.dumps(res, indent=0)); pickle.dump(dict(z=z, se=se, names=names, cov=cov, S=S, Sv=Sv, tot_var=tot, ll=ll, grad=gm, mineig=ev.min(), hv=hv), open('final_fit_v4b.pkl', 'wb'))
