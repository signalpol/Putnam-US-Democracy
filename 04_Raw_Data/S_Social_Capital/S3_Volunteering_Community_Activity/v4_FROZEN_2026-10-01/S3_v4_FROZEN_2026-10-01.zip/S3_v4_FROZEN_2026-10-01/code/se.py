import subprocess, numpy as np, pandas as pd, json
L = {2011:(951,953,1134,1140,9),2012:(951,953,1134,1140,9),2013:(951,953,1134,1140,9),2014:(951,953,1134,1140,10),2015:(951,953,1134,1140,10)}
B = {y:4687 for y in range(2002,2011)}; B.update({2011:3870,2012:3870,2013:3870,2014:3828,2015:4595})
S = pd.read_csv('s3_cps_state_rates_2002_2015.csv')
S['b_gvf'] = S.year.map(B); S['se_gvf'] = np.sqrt(S.b_gvf / S.weighted_pop * S.value * (1 - S.value))
out = []
for y,(p1,p2,sp,wp,w) in L.items():
    yy = str(y)[2:]; mz = 'raw/sep15pub.zip' if y == 2015 else f'raw/sep{yy}.zip'
    mem = subprocess.run(['unzip','-Z1',mz],capture_output=True,text=True).stdout.split()[0]
    lines = subprocess.run(['unzip','-p',mz,mem],capture_output=True).stdout.decode('latin-1').splitlines()
    rec = [(l[814:819], l[819:821], l[92:94], l[121:123], l[160:162], l[p1-1:p1+1], l[p2-1:p2+1], l[sp-1:sp+1]) for l in lines if len(l) >= wp+9]
    d = pd.DataFrame(rec, columns=['q','o','st','age','pt','p1','p2','sup']).apply(lambda s: pd.to_numeric(s.str.strip(), errors='coerce'))
    d = d[(d.pt==2)&(d.age>=16)&(d.sup==1)]; d['vol'] = ((d.p1==1)|(d.p2==1)).astype(float)
    rz = f'raw/sep{yy}nrrep.zip'; rm = subprocess.run(['unzip','-Z1',rz],capture_output=True,text=True).stdout.split()[0]
    rl = subprocess.run(['unzip','-p',rz,rm],capture_output=True).stdout.decode('latin-1').splitlines()
    q = np.array([int(l[0:5]) for l in rl]); o = np.array([int(l[5:7]) for l in rl])
    R = np.array([[float(l[7+k*w:7+(k+1)*w]) for k in range(161)] for l in rl]) / 1e4
    rp = pd.DataFrame(R, columns=[f'r{k}' for k in range(161)]); rp['q'] = q; rp['o'] = o
    m = d.merge(rp, on=['q','o'], how='left'); miss = int(m.r0.isna().sum())
    for st, g in m.groupby('st'):
        W = g[[f'r{k}' for k in range(161)]].values; v = g.vol.values[:,None]
        th = (W*v).sum(0)/W.sum(0); se = np.sqrt(4/160*np.sum((th[1:]-th[0])**2))
        out.append(dict(year=y, state_fips=int(st), p_rep0=th[0], se_rep=se, n=len(g), unmatched=miss))
    print(y, 'matched', len(m)-miss, 'unmatched', miss, flush=True)
R = pd.DataFrame(out); M = S.merge(R, on=['year','state_fips'], how='left')
M['rep0_vs_main_absdiff'] = (M.p_rep0 - M.value).abs()
M.to_csv('s3_se_2002_2015.csv', index=False)
c = M[M.se_rep.notna() & (M.state_abbr!='DC')]
print('rep0 vs main max diff', c.rep0_vs_main_absdiff.max()); print('median ratio GVF/rep', (c.se_gvf/c.se_rep).median(), 'median rep/srs', (c.se_rep/c.se_srs_approx).median())
print(c.groupby('year').apply(lambda g: pd.Series(dict(med_rep=g.se_rep.median(), med_gvf=g.se_gvf.median(), med_srs=g.se_srs_approx.median(), corr=np.corrcoef(g.se_rep,g.se_gvf)[0,1]))).round(4))
