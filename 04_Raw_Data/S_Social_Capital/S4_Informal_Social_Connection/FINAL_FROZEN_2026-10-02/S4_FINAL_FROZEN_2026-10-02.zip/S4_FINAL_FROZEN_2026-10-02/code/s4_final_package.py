import pandas as pd, numpy as np, json, pickle, hashlib, os, shutil, scipy.stats as ss
exec(open('s4_phase2.py').read().split('YRS = list')[0]); YRS = list(range(2011, 2024))
D = 'S4_FINAL_FROZEN_2026-10-02'; shutil.rmtree(D, ignore_errors=True); [os.makedirs(f'{D}/{x}') for x in ('data', 'code', 'logs', 'qa', 'docs')]
C = pd.read_csv('S4_CANONICAL_CANDIDATE_2011_2023_v1.csv', dtype={'state_fips': str}); BC = pd.read_csv('S4_BACKCAST_EXPERIMENTAL_2000_2010_v1.csv'); fips = C.drop_duplicates('state').set_index('state').state_fips
HO = pd.read_csv('S4_HOLDOUT_VALIDATION_v1.csv').set_index('holdout'); edge_fail = HO.loc['H_EARLY_2011', 'coverage95'] < 0.90
rows = []
for _, r in BC.iterrows():
    rows.append(dict(state=r.state, state_fips=fips[r.state], year=r.year, S4_estimate=r.S4_backcast, S4_SE=r.S4_backcast_se, observation_type='MODEL_ESTIMATED', source_series='MODEL_M2_BACKCAST', direct_observation=0,
                     measurement_regime='NONE_PRE_OBSERVATION', model_estimated=1, backcast_flag=1, bridge_flag=0, undercoverage_risk=int(edge_fail), provenance=f'S4F-BC-{r.year}-{r.state}'))
for _, r in C.iterrows():
    rows.append(dict(state=r.state, state_fips=r.state_fips, year=r.year, S4_estimate=r.S4, S4_SE=r.S4_se, observation_type=r.observation_type, source_series=r.source_series, direct_observation=int(r.observation_type == 'DIRECT'),
                     measurement_regime=('UNOBSERVED_INTER_REGIME_BRIDGE' if r.year in (2014, 2015, 2016) else r.measurement_regime), model_estimated=int(r.observation_type != 'DIRECT'), backcast_flag=0,
                     bridge_flag=int(r.year in (2014, 2015, 2016)), undercoverage_risk=int(r.interval_undercoverage_risk), provenance=r.provenance_id))
F = pd.DataFrame(rows).sort_values(['year', 'state']).reset_index(drop=True); F['CI_lower'] = F.S4_estimate - 1.96 * F.S4_SE; F['CI_upper'] = F.S4_estimate + 1.96 * F.S4_SE
F = F[['state', 'state_fips', 'year', 'S4_estimate', 'S4_SE', 'CI_lower', 'CI_upper', 'observation_type', 'source_series', 'direct_observation', 'measurement_regime', 'model_estimated', 'backcast_flag', 'bridge_flag', 'undercoverage_risk', 'provenance']]
F.to_csv(f'{D}/data/S4_FINAL_2000_2023.csv', index=False)
# bridge-period sensitivity
R = {k: pickle.load(open(f'ckpt_{k}.pkl', 'rb')) for k in ('primary', 'sensA', 'lameq')}
_, S1, _, _ = kf(R['primary']['z'], R['primary']['M'], smooth=True); _, S2, _, _ = kf(R['sensA']['z'], R['sensA']['M'], smooth=True); _, S4e, _, _ = kf(R['lameq']['z'], R['lameq']['M'], smooth=True, lam_equal=True)
br = []
for y in (2014, 2015, 2016):
    t = YRS.index(y)
    for nm, Sx in (('SENS_A +FF', S2), ('equal loadings', S4e)):
        br.append(dict(year=y, spec=nm, rank_corr=float(ss.spearmanr(S1[t], Sx[t])[0]), mean_abs_level_diff=float(np.abs(S1[t] - Sx[t]).mean()), natl_mean_primary=float(S1[t].mean()), natl_mean_spec=float(Sx[t].mean())))
pd.DataFrame(br).to_csv(f'{D}/qa/S4_BRIDGE_PERIOD_SENSITIVITY.csv', index=False)
# QA
A = pd.read_csv('/home/claude/s4/out/S4_PUBLISHED_VALUE_REPRODUCTION_QA_v1.csv')
q = [('rows', len(F), 1200), ('states', F.state.nunique(), 50), ('years', f'{F.year.min()}-{F.year.max()} ({F.year.nunique()})', '2000-2023 (24)'), ('duplicates', int(F.duplicated(['state', 'year']).sum()), 0),
     ('DC/territories', int((~F.state.isin(C.state.unique())).sum()), 0), ('missing S4_estimate', int(F.S4_estimate.isna().sum()), 0), ('missing S4_SE', int(F.S4_SE.isna().sum()), 0),
     ('DIRECT rows', int(F.direct_observation.sum()), 300), ('MODEL_ESTIMATED rows', int(F.model_estimated.sum()), 900), ('DIRECT/MODEL exclusive', int(((F.direct_observation + F.model_estimated) != 1).sum()), 0),
     ('backcast rows (2000-2010)', int(F.backcast_flag.sum()), 550), ('bridge rows (2014-2016)', int(F.bridge_flag.sum()), 150), ('undercoverage_risk rows', int(F.undercoverage_risk.sum()), 'documented'),
     ('direct source reproduction (AmeriCorps)', f'{int(A.match_rounding_tol_0005.sum())}/{len(A)} max {A.abs_diff.max():.5f}', '600/600'), ('interpolation/ffill/bfill', 0, 0)]
pd.DataFrame(q, columns=['check', 'observed', 'expected']).to_csv(f'{D}/qa/S4_QA_FINAL.csv', index=False)
print(pd.DataFrame(q).to_string()); print(pd.DataFrame(br).round(4).to_string())
