import subprocess, numpy as np, pandas as pd, json, hashlib, os, datetime
FIPS = {1:'AL',2:'AK',4:'AZ',5:'AR',6:'CA',8:'CO',9:'CT',10:'DE',11:'DC',12:'FL',13:'GA',15:'HI',16:'ID',17:'IL',18:'IN',19:'IA',20:'KS',21:'KY',22:'LA',23:'ME',24:'MD',25:'MA',26:'MI',27:'MN',28:'MS',29:'MO',30:'MT',31:'NE',32:'NV',33:'NH',34:'NJ',35:'NM',36:'NY',37:'NC',38:'ND',39:'OH',40:'OK',41:'OR',42:'PA',44:'RI',45:'SC',46:'SD',47:'TN',48:'TX',49:'UT',50:'VT',51:'VA',53:'WA',54:'WV',55:'WI',56:'WY'}
CEV = '/home/claude/s3/cev/'; LOG = []
def log(*a): s = ' '.join(map(str, a)); print(s, flush=True); LOG.append(s)
def unz(zf):
    m = subprocess.run(['unzip', '-Z1', zf], capture_output=True, text=True).stdout.split()[0]
    return subprocess.run(['unzip', '-p', zf, m], capture_output=True).stdout.decode('latin-1').splitlines()
def fw(zf, pos, minlen):
    L = [l for l in unz(zf) if len(l) >= minlen]
    return pd.DataFrame({k: pd.to_numeric(pd.Series([l[a-1:b] for l in L]).str.strip(), errors='coerce') for k, (a, b) in pos.items()})
def rep_dat(zf):
    L = unz(zf); A = np.array([[float(l[7+10*k:17+10*k]) for k in range(161)] for l in L]) / 1e4
    R = pd.DataFrame(A, columns=[f'r{k}' for k in range(161)]); R['QSTNUM'] = [int(l[0:5]) for l in L]; R['OCCURNUM'] = [int(l[5:7]) for l in L]; return R
B = dict(GESTFIPS=(93, 94), PRTAGE=(122, 123), PRPERTYP=(161, 162), QSTNUM=(815, 819), OCCURNUM=(820, 821))
SPEC = {
 2011: dict(kind='fw', src=('src/nov11pub.zip', 'src/nov11nrrep.zip'), pos=dict(B, FF=(975, 976), NB=(977, 978), FV=(979, 980), PRSUPINT=(995, 996), PWNRWGT=(1007, 1016)), minlen=1016, raw=dict(FF='PES13', NB='PES15', FV='PES16'), survey='CPS Civic Engagement Supplement, Nov 2011', regime='A_CE_2011_2013', doc='cpsnov11.pdf'),
 2013: dict(kind='fw', src=('src/nov13pub.zip', 'src/nov13nrrep.zip'), pos=dict(B, FF=(975, 976), NB=(977, 978), FV=(979, 980), PRSUPINT=(991, 992), PWNRWGT=(1003, 1012)), minlen=1012, raw=dict(FF='PES13', NB='PES15', FV='PES16'), survey='CPS Civic Engagement Supplement, Nov 2013', regime='A_CE_2011_2013', doc='cpsnov13.pdf'),
 2017: dict(kind='fw', src=(CEV + 'sep17pub.zip', CEV + 'sep17rep.zip'), pos=dict(B, FF=(1001, 1002), NB=(1007, 1008), FV=(1011, 1012), PRSUPINT=(1092, 1093), PWNRWGT=(1098, 1107)), minlen=1107, raw=dict(FF='PES1', NB='PES4', FV='PES6'), survey='CPS CEV, Sep 2017', regime='B_CEV_2017_2023', doc='cpssep17.pdf'),
 2019: dict(kind='fw', src=(CEV + 'sep19pub.zip', CEV + 'sep19rep.zip'), pos=dict(B, FF=(1001, 1002), NB=(1005, 1006), FV=(1009, 1010), PRSUPINT=(1042, 1043), PWNRWGT=(1048, 1057)), minlen=1057, raw=dict(FF='PES1', NB='PES4', FV='PES6'), survey='CPS CEV, Sep 2019', regime='B_CEV_2017_2023', doc='cpssept19.pdf'),
 2021: dict(kind='csv', src=(CEV + 'sep21pub.csv', CEV + 'sep21nrrep.csv'), raw=dict(FF='PES1', NB='PES4', FV='PES6'), survey='CPS CEV, Sep 2021', regime='B_CEV_2017_2023', doc='cpssept21.pdf'),
 2023: dict(kind='csv', src=(CEV + 'sep23pub.csv', CEV + 'sep23nrrep.csv'), raw=dict(FF='PES1', NB='PES4', FV='PES6'), survey='CPS CEV, Sep 2023', regime='B_CEV_2017_2023', doc='cpssep23.pdf')}
# --- 2009 attempt (NBER mirror) ---
for u in ('https://data.nber.org/cps/cpsnov09.zip', 'https://data.nber.org/cps/cpsnov09c.zip'):
    f = 'src/' + u.split('/')[-1]; code = subprocess.run(['curl', '-sL', '--max-time', '240', '-w', '%{http_code}', '-o', f, u], capture_output=True, text=True).stdout
    open('src/download_log.txt', 'a').write(f"{os.path.basename(f)} {code} {datetime.datetime.utcnow():%Y-%m-%dT%H:%M:%SZ} {u}\n"); log('2009 attempt', u, code, os.path.getsize(f))
ok09 = [f for f in ('src/cpsnov09.zip', 'src/cpsnov09c.zip') if os.path.exists(f) and os.path.getsize(f) > 1e6]
if ok09:
    SPEC[2009] = dict(kind='fw', src=(ok09[0], None), pos=dict(B, NB=(973, 974), FV=(975, 976), PRSUPINT=(979, 980), PWNRWGT=(981, 990)), minlen=990, raw=dict(NB='PEQ10', FV='PEQ11'), survey='CPS Civic Engagement Supplement, Nov 2009 (NBER mirror)', regime='A0_CE_2009', doc='cpsnov09c.pdf')
rows, meta, dist = [], [], []
for y, s in sorted(SPEC.items()):
    if s['kind'] == 'fw':
        d = fw(s['src'][0], s['pos'], s['minlen']); d['PWNRWGT'] = d.PWNRWGT / 1e4; R = rep_dat(s['src'][1]) if s['src'][1] else None
    else:
        keep = ['GESTFIPS', 'PRTAGE', 'PRPERTYP', 'QSTNUM', 'OCCURNUM', 'PRSUPINT', 'PWNRWGT'] + list(s['raw'].values())
        d = pd.read_csv(s['src'][0], usecols=lambda c: c.upper() in keep); d.columns = [c.upper() for c in d.columns]; d = d.rename(columns={v: k for k, v in s['raw'].items()})
        R = pd.read_csv(s['src'][1]); R.columns = [c.upper() for c in R.columns]; R = R.rename(columns={f'PWNRWGT{k}': f'r{k}' for k in range(161)})
        if R['r0'].sum() > 1e10: R[[f'r{k}' for k in range(161)]] /= 1e4
        if d.PWNRWGT.sum() > 1e10: d['PWNRWGT'] /= 1e4
    u = d[(d.PRPERTYP == 2) & (d.PRSUPINT == 1)].copy()
    if R is not None: u = u.merge(R, on=['QSTNUM', 'OCCURNUM'], how='left')
    meta.append(dict(year=y, survey=s['survey'], regime=s['regime'], files=[os.path.basename(x) for x in s['src'] if x], sha256=[hashlib.sha256(open(x, 'rb').read()).hexdigest() for x in s['src'] if x],
                     n_supp_resp=len(u), age_min=int(u.PRTAGE.min()), unmatched_rep=int(u.r0.isna().sum()) if R is not None else None, replicate=R is not None, doc=s['doc']))
    st = u.GESTFIPS.map(FIPS).values; states = sorted(set(st) - {'DC', None})
    for k in s['raw']:
        vc = u.groupby(k).PWNRWGT.sum(); dist.append(dict(year=y, indicator=k, raw_var=s['raw'][k], **{f'code_{int(c)}': float(v / vc.sum()) for c, v in vc.items()}))
        for den in ('valid_1to6', 'all_supp_resp'):
            for thr, lab in ((5, 'ANY_1to5_at_least_once'), (3, 'FREQ_1to3_few_times_month_plus')):
                m = u[u[k].between(1, 6)] if den == 'valid_1to6' else u
                yv = m[k].between(1, thr).astype(float).values; w = m.PWNRWGT.values; sm = m.GESTFIPS.map(FIPS).values
                W = m[[f'r{i}' for i in range(161)]].values if R is not None else None
                for s_ in states:
                    ix = sm == s_; p = (yv[ix] * w[ix]).sum() / w[ix].sum()
                    if W is not None:
                        th = (W[ix] * yv[ix, None]).sum(0) / W[ix].sum(0); se = float(np.sqrt(4 / 160 * np.sum((th[1:] - th[0]) ** 2))); r0 = float(th[0] - p)
                    else: se, r0 = np.nan, np.nan
                    rows.append(dict(year=y, regime=s['regime'], indicator=k, raw_var=s['raw'][k], definition=lab, denominator=den, state_abbr=s_, n_unweighted=int(ix.sum()), estimate=p, se=se, se_method='REPLICATE_SDR_160 Var=4/160*sum(theta_r-theta_0)^2' if W is not None else 'NOT_AVAILABLE', rep0_minus_point=r0))
    log(y, 'done', len(rows))
O = pd.DataFrame(rows); O.to_csv('out/s4_all_definition_variants.csv', index=False); json.dump(meta, open('out/s4_meta.json', 'w'), indent=1); pd.DataFrame(dist).to_csv('out/s4_national_distributions.csv', index=False)
open('out/s4_gate1_run.log', 'w').write('\n'.join(LOG))
