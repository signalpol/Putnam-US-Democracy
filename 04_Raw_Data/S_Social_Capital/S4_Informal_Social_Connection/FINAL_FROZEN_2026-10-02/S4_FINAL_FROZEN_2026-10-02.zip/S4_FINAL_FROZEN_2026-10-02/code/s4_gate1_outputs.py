import pandas as pd, numpy as np, json, hashlib, os, glob
O = pd.read_csv('out/s4_all_definition_variants.csv'); meta = json.load(open('out/s4_meta.json')); D = pd.read_csv('out/s4_national_distributions.csv')
A = pd.read_csv('src/americorps_4r6x-re58.csv').set_index('State'); NM = dict(FF='Talking with Friends and Family', NB='Talking with Neighbors', FV='Informal Helping')
# reproduction search (documented: official definition says 'at least once in the past year'; denominator not documented)
rs = []
for (k, y, df, den), g in O[O.year >= 2017].groupby(['indicator', 'year', 'definition', 'denominator']):
    pub = A[f'State {y} {NM[k]} Rate']; e = g.set_index('state_abbr').estimate; dif = (e - pub.loc[e.index]).abs()
    rs.append(dict(indicator=k, year=y, definition=df, denominator=den, n=len(dif), mae=dif.mean(), maxabs=dif.max(), n_within_0005=int((dif <= 0.0005 + 1e-9).sum())))
RS = pd.DataFrame(rs); RS.to_csv('out/S4_DEFINITION_REPRODUCTION_SEARCH_v1.csv', index=False)
best = RS.groupby(['definition', 'denominator']).agg(mae=('mae', 'mean'), within=('n_within_0005', 'sum'), n=('n', 'sum')).reset_index().sort_values('mae'); print(best.to_string())
DEF, DEN = 'ANY_1to5_at_least_once', best[best.definition == 'ANY_1to5_at_least_once'].iloc[0].denominator
P = O[(O.definition == DEF) & (O.denominator == DEN)].copy(); P['observation_type'] = 'DIRECT'
P['equivalence_class'] = np.where(P.year == 2009, 'PARTIAL_DIRECT_YEAR_CANDIDATE', np.where(P.regime.str.startswith('B'), 'REGIME_B', 'REGIME_A'))
P.to_csv('out/S4_DIRECT_INDICATOR_PANEL_v1.csv', index=False)
# reproduction QA (official definition, published values as benchmark only; published are rounded to 3 decimals)
q = []
for _, r in P[P.year >= 2017].iterrows():
    pub = A.loc[r.state_abbr, f'State {r.year} {NM[r.indicator]} Rate']; q.append(dict(year=r.year, indicator=r.indicator, state_abbr=r.state_abbr, computed=r.estimate, published=pub, abs_diff=abs(r.estimate - pub), match_rounding_tol_0005=abs(r.estimate - pub) <= 0.0005 + 1e-9))
Q = pd.DataFrame(q); Q.to_csv('out/S4_PUBLISHED_VALUE_REPRODUCTION_QA_v1.csv', index=False)
print('repro', len(Q), int(Q.match_rounding_tol_0005.sum()), Q.abs_diff.max(), Q.abs_diff.mean()); print(Q[~Q.match_rounding_tol_0005].groupby(['indicator', 'year']).size())
# FF / indicator diagnostics
dg = []
for (k, reg), g in P[P.year != 2009].groupby(['indicator', 'regime']):
    piv = g.pivot(index='state_abbr', columns='year', values='estimate')
    dg.append(dict(indicator=k, regime=reg, years=list(piv.columns), mean=float(piv.values.mean()), cross_sectional_sd_mean=float(piv.std(axis=0).mean()),
                   between_state_var=float(piv.mean(axis=1).var()), within_state_temporal_var=float(piv.sub(piv.mean(axis=1), axis=0).pow(2).sum().sum() / max(piv.size - len(piv), 1)),
                   mean_se=float(g.se.mean()), mean_sampling_var=float((g.se ** 2).mean())))
DG = pd.DataFrame(dg)
for reg in ('A_CE_2011_2013', 'B_CEV_2017_2023'):
    w = P[P.regime == reg].pivot_table(index=['state_abbr', 'year'], columns='indicator', values='estimate'); c = w.corr()
    for k in ('FF', 'NB', 'FV'):
        for k2 in ('FF', 'NB', 'FV'):
            if k < k2: DG.loc[len(DG)] = dict(indicator=f'corr {k}-{k2}', regime=reg, mean=float(c.loc[k, k2]))
DG.to_csv('out/S4_INDICATOR_VARIANCE_DIAGNOSTICS_v1.csv', index=False); print(DG.round(5).to_string())
# measurement dictionary
W = {'FF': {'A': "PES13: 'This next question is about friends and family (you do/NAME does) not live with. During the last twelve months, how often did (you/NAME) see or hear from friends or family, whether in-person or not'", 'B': "PES1: 'In the past 12 months ... how often did [you] talk to or spend time with friends and family?'"},
     'NB': {'A': "PES15: 'How often did (you/NAME) talk with any of (your/his/her) neighbors'", 'B': "PES4: 'In the past 12 months, how often did [you] have a conversation or spend time with [your] neighbors?'", 'A0': "PEQ10: 'How often did you talk with any of your neighbors'"},
     'FV': {'A': "PES16: 'How often did (you/NAME) and (your/his/her) neighbors do favors for each other? By favors we mean such things as watching each others children, helping with shopping, house sitting, lending garden or house tools...'", 'B': "PES6: 'how often did [you] and [your] neighbors do favors for each other such as house sitting, watching each other's children, lending tools, and other things to help each other'", 'A0': "PEQ11: 'How often did you and your neighbors do favors for each other?'"}}
dic = []
for m in meta:
    reg = 'A0' if m['year'] == 2009 else m['regime'][0]
    for k, raw in ({'NB': 'PEQ10', 'FV': 'PEQ11'} if m['year'] == 2009 else dict(zip(['FF', 'NB', 'FV'], ['PES13', 'PES15', 'PES16'] if reg == 'A' else ['PES1', 'PES4', 'PES6']))).items():
        dic.append(dict(year=m['year'], survey=m['survey'], construct={'FF': 'Friends/Family Social Interaction', 'NB': 'Neighbor Interaction', 'FV': 'Informal Helping (favors with neighbors)'}[k], variable=raw, wording=W[k][reg],
                        response_scale='1 every day;2 few/week;3 few/month;4 once/month;5 <once/month;6 not at all', reference_period=('typical month / last 12 months (Nov)' if reg != 'B' else 'past 12 months (Sep)'),
                        universe=f"PRPERTYP=2 & PRSUPINT=1 (observed min age {m['age_min']})", weight='PWNRWGT', replicate_weights='repwgt1..160 (nrrep/rep file)' if m['replicate'] else 'NONE AVAILABLE',
                        missing_codes='-1 NIU, -2 DK, -3 refused, -9 no answer: excluded from denominator (valid 1-6)' if DEN == 'valid_1to6' else 'negative codes kept in denominator as non-yes', source=';'.join(m['files']), codebook=m['doc']))
pd.DataFrame(dic).to_csv('out/S4_MEASUREMENT_DICTIONARY_v1.csv', index=False)
eq = [dict(indicator='FF', pair='A(2011,2013) vs B(2017-2023)', wording='NON-EQUIVALENT', detail="A: see OR hear from (incl. not in person) friends/family NOT living with R; B: talk to or spend time with friends and family (any)", period='Nov vs Sep; typical-month framing vs 12 months', universe='A min age vs B 16+ (see dictionary)', verdict='NON-EQUIVALENT'),
      dict(indicator='NB', pair='A vs B', wording='NEAR-EQUIVALENT', detail="'talk with any of your neighbors' vs 'have a conversation or spend time with neighbors'", period='Nov vs Sep', universe='see dictionary', verdict='NEAR-EQUIVALENT'),
      dict(indicator='FV', pair='A vs B', wording='NEAR-EQUIVALENT', detail='same favors construct and examples; minor example list change', period='Nov vs Sep', universe='see dictionary', verdict='NEAR-EQUIVALENT'),
      dict(indicator='NB/FV', pair='A0(2009) vs A', wording='EQUIVALENT (near-identical text)', detail='2009 lacks equivalent FF item (PEQ9 = email/internet contact)', period='Nov', universe='see dictionary', verdict='EQUIVALENT_for_NB_FV; FF unavailable'),
      dict(indicator='all', pair='within B 2017-2023', wording='EQUIVALENT', detail='identical wording; variable numbering changed (2017 PES4 at 1007, 2019+ at 1005)', period='Sep', universe='16+', verdict='EQUIVALENT')]
pd.DataFrame(eq).to_csv('out/S4_MEASUREMENT_EQUIVALENCE_AUDIT_v1.csv', index=False)
# QA
qa = [('direct cells', len(P)), ('states per year-indicator min/max', f"{P.groupby(['year','indicator']).state_abbr.nunique().min()}/{P.groupby(['year','indicator']).state_abbr.nunique().max()}"),
      ('duplicates year-state-indicator', int(P.duplicated(['year', 'state_abbr', 'indicator']).sum())), ('estimate range', f'{P.estimate.min():.4f}-{P.estimate.max():.4f}'),
      ('official SE coverage', f"{int(P.se.notna().sum())}/{len(P)}"), ('rep0 vs point max abs', float(P.rep0_minus_point.abs().max())),
      ('replicate unmatched persons', {m['year']: m['unmatched_rep'] for m in meta}), ('DC excluded', bool('DC' not in set(P.state_abbr))), ('interpolation/model cells', 0)]
pd.DataFrame(qa, columns=['check', 'value']).to_csv('out/S4_DIRECT_QA_v1.csv', index=False); print(pd.DataFrame(qa).to_string())
man = []
for m in meta:
    for f, h in zip(m['files'], m['sha256']): man.append(dict(year=m['year'], survey=m['survey'], file=f, sha256=h, codebook=m['doc']))
man.append(dict(year='2017-2023', survey='AmeriCorps CEV state rates 4r6x-re58 (benchmark only)', file='americorps_4r6x-re58.csv', sha256=hashlib.sha256(open('src/americorps_4r6x-re58.csv', 'rb').read()).hexdigest(), codebook='data.americorps.gov'))
pd.DataFrame(man).to_csv('out/S4_SOURCE_MANIFEST_v1.csv', index=False)
open('out/S4_DOWNLOAD_LOG_v1.txt', 'w').write(open('src/download_log.txt').read() + open('/home/claude/s3/cev/download_log.txt').read() + 'americorps_4r6x-re58.csv ' + open('src/americorps_4r6x-re58.retrieved.txt').read())
print(D[D.year == 2009].round(3).to_string())
