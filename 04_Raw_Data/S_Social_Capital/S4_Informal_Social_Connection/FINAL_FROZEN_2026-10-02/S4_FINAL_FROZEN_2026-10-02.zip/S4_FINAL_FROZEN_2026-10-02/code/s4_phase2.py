import numpy as np, pandas as pd, json, time, sys
from scipy.optimize import minimize
np.random.seed(20261001)
P = pd.read_csv('../out/S4_DIRECT_INDICATOR_PANEL_v1.csv'); P = P[(P.year != 2009) & (P.observation_type == 'DIRECT')].copy()
P['reg'] = np.where(P.regime.str.startswith('A'), 'A', 'B'); ST = sorted(P.state_abbr.unique()); NS = 50
def setup(inds, anchor, years, drop=()):
    pairs = sorted({(k, r) for k in inds for r in 'AB'}); free = [p for p in pairs if p != anchor]
    obs = {t: [] for t in range(len(years))}
    for _, r in P[P.indicator.isin(inds) & ~P.year.isin(drop)].iterrows():
        obs[years.index(r.year)].append((ST.index(r.state_abbr), pairs.index((r.indicator, r.reg)), r.estimate, r.se ** 2))
    return dict(pairs=pairs, free=free, anchor=anchor, obs=obs, years=years, T=len(years))
def unpack(th, M, lam_equal=False):
    p = dict(m0=th[0], s0=np.exp(th[1]), qu=np.exp(th[2]), qm=np.exp(th[3])); a = {M['anchor']: 0.0}; l = {M['anchor']: 1.0}; i = 4
    for pr in M['free']:
        a[pr] = th[i]; i += 1
        if lam_equal and pr[0] == M['anchor'][0]: l[pr] = 1.0
        elif lam_equal: l[pr] = None
        else: l[pr] = th[i]; i += 1
    if lam_equal:
        for k in {pr[0] for pr in M['pairs']} - {M['anchor'][0]}:
            v = th[i]; i += 1
            for pr in M['pairs']:
                if pr[0] == k: l[pr] = v
    tau = {}
    for pr in M['pairs']: tau[pr] = np.exp(th[i]); i += 1
    return p, a, l, tau
def npar(M, lam_equal=False):
    ks = {pr[0] for pr in M['pairs']}
    return 4 + len(M['free']) + (len(ks) - 1 if lam_equal else len(M['free'])) + len(M['pairs'])
def kf(th, M, smooth=False, lam_equal=False):
    p, a, l, tau = unpack(th, M, lam_equal); n = NS + 1; x = np.zeros(n); x[0] = p['m0']; Pm = np.diag([0.0] + [p['s0'] ** 2] * NS)
    Q = np.diag([p['qm']] + [p['qu']] * NS); ll = 0.0; XF, PF, XP, PP = [], [], [], []
    A = np.array([a[pr] for pr in M['pairs']]); L = np.array([l[pr] for pr in M['pairs']]); TA = np.array([tau[pr] for pr in M['pairs']])
    for t in range(M['T']):
        if t: Pm = Pm + Q
        XP.append(x.copy()); PP.append(Pm.copy())
        for s, j, y, v in M['obs'][t]:
            lj = L[j]; ph = lj * (Pm[:, 0] + Pm[:, s + 1]); F = lj * (ph[0] + ph[s + 1]) + v + TA[j] ** 2; e = y - A[j] - lj * (x[0] + x[s + 1])
            ll += -0.5 * (np.log(2 * np.pi * F) + e * e / F); K = ph / F; x = x + K * e; Pm = Pm - np.outer(K, ph)
        XF.append(x.copy()); PF.append(Pm.copy())
    if not smooth: return ll
    xs, Ps = [None] * M['T'], [None] * M['T']; xs[-1], Ps[-1] = XF[-1], PF[-1]
    for t in range(M['T'] - 2, -1, -1):
        J = PF[t] @ np.linalg.pinv(PP[t + 1]); xs[t] = XF[t] + J @ (xs[t + 1] - XP[t + 1]); Ps[t] = PF[t] + J @ (Ps[t + 1] - PP[t + 1]) @ J.T
    S = np.array([xs[t][0] + xs[t][1:] for t in range(M['T'])]); V = np.array([np.diag(Ps[t])[1:] + Ps[t][0, 0] + 2 * Ps[t][0, 1:] for t in range(M['T'])])
    return ll, S, V, (p, a, l, tau)
def hess(f, x, h=1e-4):
    k = len(x); H = np.zeros((k, k))
    for i in range(k):
        for j in range(i, k):
            e1, e2 = np.eye(k)[i] * h, np.eye(k)[j] * h; H[i, j] = H[j, i] = (f(x + e1 + e2) - f(x + e1 - e2) - f(x - e1 + e2) + f(x - e1 - e2)) / (4 * h * h)
    return H
def grad(f, x, h=1e-5): return np.array([(f(x + np.eye(len(x))[i] * h) - f(x - np.eye(len(x))[i] * h)) / (2 * h) for i in range(len(x))])
def fit(M, starts=3, lam_equal=False, polish=True, tag=''):
    t0 = time.time(); k = npar(M, lam_equal); f = lambda th: -kf(th, M, lam_equal=lam_equal); best = None; runs = []
    for s in range(starts):
        th0 = np.r_[0.7, np.log(0.05), np.log(1e-4), np.log(1e-4), np.zeros(0)]
        rest = []
        for pr in M['free']:
            rest.append(0.0)
            if not lam_equal: rest.append(1.0)
        if lam_equal: rest += [1.0] * (len({pr[0] for pr in M['pairs']}) - 1)
        rest += [np.log(0.01)] * len(M['pairs']); th0 = np.r_[th0, rest]
        if s: th0 = th0 + np.random.normal(0, 0.2, k)
        try:
            r = minimize(f, th0, method='L-BFGS-B', options=dict(maxiter=800)); runs.append(dict(start=s, fun=float(r.fun), success=bool(r.success), msg=str(r.message)[:80]))
            if best is None or r.fun < best.fun: best = r
        except Exception as ex: runs.append(dict(start=s, error=repr(ex)[:200]))
    z = best.x
    if polish:
        for _ in range(15):
            g = grad(f, z)
            if np.abs(g).max() < 1e-3: break
            try: z = z - np.linalg.solve(hess(f, z), g)
            except Exception: break
    H = hess(f, z); ev = np.linalg.eigvalsh(H); g = grad(f, z)
    out = dict(tag=tag, ll=-f(z), k=k, AIC=2 * f(z) + 2 * k, grad_max=float(np.abs(g).max()), hess_min_eig=float(ev.min()), hess_pd=bool(ev.min() > 0), lbfgs_success=best.success, starts=runs, seconds=round(time.time() - t0, 1))
    print(json.dumps({kk: v for kk, v in out.items() if kk != 'starts'}, default=float), flush=True)
    return z, H, out
YRS = list(range(2011, 2024))
