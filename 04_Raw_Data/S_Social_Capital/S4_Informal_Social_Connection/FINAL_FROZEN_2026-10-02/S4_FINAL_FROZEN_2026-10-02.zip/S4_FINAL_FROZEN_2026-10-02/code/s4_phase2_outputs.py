exec(open('s4_phase2.py').read().split('YRS = list')[0]); YRS = list(range(2011, 2024))
import pickle, hashlib, scipy.stats as ss
R = pickle.load(open('phase2_fits.pkl', 'rb')); FIPS = pd.read_csv('/home/claude/s3/out/S3_Volunteering_Community_Activity_CANONICAL_RAW_v2.csv', dtype={'state_fips': str}).drop_duplicates('state_abbr').set_index('state_abbr').state_fips
def smooth(key, lam_equal=False):
    d = R[key]; return kf(d['z'], d['M'], smooth=True, lam_equal=lam_equal)
def total_var(key, n=200, lam_equal=False):
    d = R[key]; cov = np.linalg.inv(d['H']); Ss, Vs = [], []
    for zz in np.random.multivariate_normal(d['z'], cov, n):
        try: _, s_, v_, _ = kf(zz, d['M'], smooth=True, lam_equal=lam_equal); Ss.append(s_); Vs.append(v_)
        except Exception: pass
    Ss, Vs = np.array(Ss), np.array(Vs); return Vs.mean(0) + Ss.var(0), len(Ss)
_, S1, V1, (p, a, l, tau) = smooth('primary'); TV1, ndraw = total_var('primary')
# direct composite (GLS, single-year info only) on latent scale
def direct_comp(params, inds):
    p_, a_, l_, t_ = params; out = {}
    for (y, st), g in P[P.indicator.isin(inds)].groupby(['year', 'state_abbr']):
        x, w = [], []
        for _, r in g.iterrows():
            pr = (r.indicator, r.reg); x.append((r.estimate - a_[pr]) / l_[pr]); w.append(l_[pr] ** 2 / (r.se ** 2 + t_[pr] ** 2))
        x, w = np.array(x), np.array(w); out[(y, st)] = (float((x * w).sum() / w.sum()), float(np.sqrt(1 / w.sum())))
    return out
DC = direct_comp((p, a, l, tau), ['NB', 'FV'])
H = {h: v for h, v in R['holdouts'].items()}
flag_B = any(H[h]['coverage95'] < 0.90 for h in ('H_MIDDLE_2019', 'H_LATE_2021')); flag_A = any(H[h]['coverage95'] < 0.90 for h in ('H_EARLY_2011', 'H_EARLY_MID_2013'))
rows = []
for t, y in enumerate(YRS):
    for s, st in enumerate(ST):
        if (y, st) in DC:
            v, se = DC[(y, st)]; ot = 'DIRECT'; reg = 'A_CE_2011_2013' if y < 2016 else 'B_CEV_2017_2023'; risk = 0
        else:
            v, se = S1[t, s], np.sqrt(TV1[t, s]); ot = 'MODEL_ESTIMATED'; reg = 'A_CE_2011_2013' if y in (2012,) else ('A_B_GAP' if y in (2014, 2015, 2016) else 'B_CEV_2017_2023')
            risk = int((y in (2018, 2020, 2022) and flag_B) or (y in (2012, 2014, 2015, 2016) and flag_A))
        rows.append(dict(state=st, state_fips=FIPS[st], year=y, S4=v, S4_se=se, S4_latent_smoothed=S1[t, s], S4_latent_smoothed_se=np.sqrt(TV1[t, s]), observation_type=ot,
                         source_series=('CPS_CE_NOV' if y < 2016 and ot == 'DIRECT' else ('CPS_CEV_SEP' if ot == 'DIRECT' else 'MODEL_M2')), measurement_regime=reg, model_version='S4_phase2_M2_primary_NB_FV_anchorNB_B',
                         interval_undercoverage_risk=risk, provenance_id=f'S4P2-{y}-{st}'))
C = pd.DataFrame(rows); C.to_csv('S4_CANONICAL_CANDIDATE_2011_2023_v1.csv', index=False)
# backcast experimental
_, SB, VB, _ = kf(R['backcast']['z'], R['backcast']['M'], smooth=True); TVB, _ = total_var('backcast', 100)
_, SBA, _, _ = kf(R['backcastA']['z'], R['backcastA']['M'], smooth=True)
YB = list(range(2000, 2024)); bc = []
for t, y in enumerate(YB[:11]):
    for s, st in enumerate(ST): bc.append(dict(state=st, year=y, S4_backcast=SB[t, s], S4_backcast_se=np.sqrt(TVB[t, s]), observation_type='MODEL_BACKCAST_EXPERIMENTAL', model_version='S4_phase2_M2_backcast_grid2000'))
BC = pd.DataFrame(bc); BC.to_csv('S4_BACKCAST_EXPERIMENTAL_2000_2010_v1.csv', index=False)
i11 = YB.index(2011)
bdiag = dict(mean_se_2000=float(np.sqrt(TVB[0]).mean()), mean_se_2005=float(np.sqrt(TVB[5]).mean()), mean_se_2010=float(np.sqrt(TVB[10]).mean()), mean_se_2011=float(np.sqrt(TVB[i11]).mean()),
             se_monotone_increase_backward=bool(all(np.sqrt(TVB[t]).mean() >= np.sqrt(TVB[t + 1]).mean() - 1e-9 for t in range(10))),
             rank_corr_2000_vs_2011=float(ss.spearmanr(SB[0], SB[i11])[0]), rank_corr_2000_primary_vs_sensA=float(ss.spearmanr(SB[0], SBA[0])[0]),
             mean_abs_diff_2000_primary_vs_sensA=float(np.abs(SB[0] - SBA[0]).mean()), canonical_vs_backcastgrid_2011_2023_max_abs=float(np.abs(SB[i11:] - S1).max()),
             cross_state_sd_2000=float(SB[0].std()), cross_state_sd_2011=float(SB[i11].std()), national_mean_2000=float(SB[0].mean()), national_mean_2011=float(SB[i11].mean()),
             backcast_params_vs_primary_max_abs=float(np.abs(R['backcast']['z'][1:] - R['primary']['z'][1:]).max()))
# sensitivity comparisons on 2011-2023 smoothed latent
_, S2, _, prm2 = kf(R['sensA']['z'], R['sensA']['M'], smooth=True); _, S3, _, _ = kf(R['anchorA']['z'], R['anchorA']['M'], smooth=True); _, S4e, _, prm4 = kf(R['lameq']['z'], R['lameq']['M'], smooth=True, lam_equal=True)
def cmp(Sx, name):
    rk = [ss.spearmanr(S1[t], Sx[t])[0] for t in range(13)]; tr1 = np.polyfit(range(13), S1, 1)[0]; trx = np.polyfit(range(13), Sx, 1)[0]
    return dict(spec=name, rank_corr_min=float(min(rk)), rank_corr_mean=float(np.mean(rk)), level_corr_all=float(np.corrcoef(S1.ravel(), Sx.ravel())[0, 1]), trend_slope_corr=float(np.corrcoef(tr1, trx)[0, 1]),
                yoy_change_corr=float(np.corrcoef(np.diff(S1, axis=0).ravel(), np.diff(Sx, axis=0).ravel())[0, 1]), natl_trend_primary=list(np.round(S1.mean(1), 4)), natl_trend_spec=list(np.round(Sx.mean(1), 4)),
                cross_state_var_primary=float(S1.var(1).mean()), cross_state_var_spec=float(Sx.var(1).mean()))
# M0/M1 simple composites on direct years
D = P[P.indicator.isin(['NB', 'FV'])].copy(); D['z'] = D.groupby(['indicator', 'reg']).estimate.transform(lambda x: (x - x.mean()) / x.std())
M0 = D.groupby(['year', 'state_abbr']).z.mean().unstack(); D['w'] = 1 / D.se ** 2; M1c = D.groupby(['year', 'state_abbr']).apply(lambda g: (g.z * g.w).sum() / g.w.sum()).unstack()
m2d = pd.Series({k: v[0] for k, v in DC.items()}).unstack()
simple = [dict(spec=f'{nm} vs M2 direct composite', year=y, rank_corr=float(ss.spearmanr(X.loc[y], m2d.loc[y].reindex(X.columns))[0])) for nm, X in (('M0_equal_weight', M0), ('M1_SE_weighted', M1c)) for y in X.index]
SENS = pd.DataFrame([cmp(S2, 'SENS_A NB+FV+FF'), cmp(S3, 'REGIME anchor NB_A'), cmp(S4e, 'REGIME equal loadings A=B')]); SENS.to_csv('S4_SENSITIVITY_v1.csv', index=False)
pd.DataFrame(simple).to_csv('S4_SIMPLE_COMPOSITES_M0_M1_vs_M2_v1.csv', index=False)
HO = pd.DataFrame([dict(holdout=h, **{k: v for k, v in d.items() if k != 'fit'}, fit_grad=d['fit']['grad_max'], fit_hess_pd=d['fit']['hess_pd']) for h, d in H.items()]); HO.to_csv('S4_HOLDOUT_VALIDATION_v1.csv', index=False)
fits = [dict(name=k, **{kk: vv for kk, vv in R[k]['o'].items()}) for k in ('primary', 'sensA', 'anchorA', 'lameq', 'backcast', 'backcastA')] + [dict(name=f'holdout {h}', **d['fit']) for h, d in H.items()]
pd.DataFrame(fits).to_csv('S4_MODEL_FITS_AND_DIAGNOSTICS_v1.csv', index=False)
pr = pd.DataFrame([dict(pair=f'{k}_{r}', alpha=a[(k, r)], lambda_=l[(k, r)], tau=tau[(k, r)]) for (k, r) in R['primary']['M']['pairs']]); pr['m0'], pr['s0'], pr['qu'], pr['qm'] = p['m0'], p['s0'], p['qu'], p['qm']
se_th = np.sqrt(np.diag(np.linalg.inv(R['primary']['H']))); pr.to_csv('S4_MODEL_PARAMETERS_PRIMARY_v1.csv', index=False); pd.DataFrame(dict(theta=R['primary']['z'], se=se_th)).to_csv('S4_MODEL_THETA_SE_PRIMARY_v1.csv', index=False)
json.dump(bdiag, open('S4_BACKCAST_DIAGNOSTICS_v1.json', 'w'), indent=1)
qa = dict(rows=len(C), states=C.state.nunique(), years=sorted(C.year.unique().tolist()) == YRS, dup=int(C.duplicated(['state', 'year']).sum()), direct=int((C.observation_type == 'DIRECT').sum()), modeled=int((C.observation_type == 'MODEL_ESTIMATED').sum()),
          missing_S4=int(C.S4.isna().sum()), missing_se=int(C.S4_se.isna().sum()), risk_flagged=int(C.interval_undercoverage_risk.sum()), indicator_direct_cells_used=int(P.indicator.isin(['NB', 'FV']).sum()), indicator_se_coverage=f"{int(P[P.indicator.isin(['NB','FV'])].se.notna().sum())}/{int(P.indicator.isin(['NB','FV']).sum())}",
          param_draws_used=ndraw, backcast_rows_separate=len(BC), backcast_merged_into_canonical=False, interpolation=0)
json.dump(qa, open('S4_PHASE2_QA_v1.json', 'w'), indent=1)
print(json.dumps(qa)); print(HO[['holdout', 'MAE', 'RMSE', 'mean_error', 'coverage95', 'state_residual_sd', 'national_bias_by_indicator']].to_string()); print(SENS[['spec', 'rank_corr_min', 'rank_corr_mean', 'level_corr_all', 'trend_slope_corr', 'yoy_change_corr']].round(3).to_string())
print(pd.DataFrame(simple).groupby('spec').rank_corr.agg(['min', 'mean']).round(3)); print(pr.round(4).to_string()); print(json.dumps(bdiag, indent=0)); print('flags', flag_A, flag_B)
