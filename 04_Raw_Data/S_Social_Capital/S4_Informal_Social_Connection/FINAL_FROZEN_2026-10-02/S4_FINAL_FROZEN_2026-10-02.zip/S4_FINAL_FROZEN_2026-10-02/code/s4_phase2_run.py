exec(open('s4_phase2.py').read())
import pickle, hashlib
import os
def ck(name, fn):
    f = f'ckpt_{name}.pkl'
    if os.path.exists(f): print('loaded', name, flush=True); return pickle.load(open(f, 'rb'))
    v = fn(); pickle.dump(v, open(f, 'wb')); return v
R = {}; HD = json.load(open('HOLDOUT_DESIGN_PREREGISTERED.json'))['holdouts']
def holdout_eval(inds, anchor, yrs_out, lam_equal=False):
    M = setup(inds, anchor, YRS, drop=yrs_out); z, H, o = fit(M, starts=2, lam_equal=lam_equal, tag=f'holdout {yrs_out}')
    _, S, V, (p, a, l, tau) = kf(z, M, smooth=True, lam_equal=lam_equal); res = []
    for _, r in P[P.indicator.isin(inds) & P.year.isin(yrs_out)].iterrows():
        pr = (r.indicator, r.reg); t = YRS.index(r.year); s = ST.index(r.state_abbr)
        mu = a[pr] + l[pr] * S[t, s]; sd = np.sqrt(l[pr] ** 2 * V[t, s] + r.se ** 2 + tau[pr] ** 2); res.append(dict(year=r.year, indicator=r.indicator, state=r.state_abbr, err=r.estimate - mu, z=(r.estimate - mu) / sd))
    E = pd.DataFrame(res); nat = E.groupby('indicator').err.mean().to_dict()
    return dict(MAE=float(E.err.abs().mean()), RMSE=float(np.sqrt((E.err ** 2).mean())), mean_error=float(E.err.mean()), coverage95=float((E.z.abs() < 1.96).mean()),
                state_residual_sd=float(E.groupby('state').err.mean().std()), national_bias_by_indicator=nat, n=len(E), fit=o)
# 1 primary
M1 = setup(['NB', 'FV'], ('NB', 'B'), YRS); R['primary'] = ck('primary', lambda: (lambda r: dict(z=r[0], H=r[1], o=r[2], M=M1))(fit(M1, tag='PRIMARY NB+FV anchor NB_B')))
R['holdouts'] = {h: ck('ho_' + h, lambda y=y: holdout_eval(['NB', 'FV'], ('NB', 'B'), y)) for h, y in HD.items()}
# sensitivity A: + FF
M2 = setup(['NB', 'FV', 'FF'], ('NB', 'B'), YRS); R['sensA'] = ck('sensA', lambda: (lambda r: dict(z=r[0], o=r[2], M=M2))(fit(M2, starts=2, tag='SENS_A NB+FV+FF')))
# regime sensitivity
M3 = setup(['NB', 'FV'], ('NB', 'A'), YRS); R['anchorA'] = ck('anchorA', lambda: (lambda r: dict(z=r[0], o=r[2], M=M3))(fit(M3, starts=1, tag='REGIME_SENS anchor NB_A')))
R['lameq'] = ck('lameq', lambda: (lambda r: dict(z=r[0], o=r[2], M=M1))(fit(M1, starts=2, lam_equal=True, tag='REGIME_SENS equal loadings A=B (intercept-only break)')))
# experimental backcast grid 2000-2023
YB = list(range(2000, 2024)); MB = setup(['NB', 'FV'], ('NB', 'B'), YB); R['backcast'] = ck('backcast', lambda: (lambda r: dict(z=r[0], H=r[1], o=r[2], M=MB))(fit(MB, starts=2, tag='EXPERIMENTAL BACKCAST grid 2000-2023')))
MB2 = setup(['NB', 'FV', 'FF'], ('NB', 'B'), YB); R['backcastA'] = ck('backcastA', lambda: (lambda r: dict(z=r[0], o=r[2], M=MB2))(fit(MB2, starts=1, tag='EXPERIMENTAL BACKCAST SENS_A')))
pickle.dump(R, open('phase2_fits.pkl', 'wb')); print('ALL FITS DONE', flush=True)
