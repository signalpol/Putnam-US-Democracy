import numpy as np, pandas as pd, json, pickle, os, time
from scipy.optimize import minimize
np.random.seed(20261002)
D = pd.read_csv('../src/Turnout_1980_2022_v1.2.csv', thousands=',')
D['STATE'] = D.STATE.str.rstrip('*'); D = D[D.YEAR.between(2000, 2022) & ~D.STATE.isin(['United States', 'District of Columbia'])].copy()
num = lambda s: pd.to_numeric(s.astype(str).str.replace(',', '').str.replace('%', ''), errors='coerce')
for c in ('TOTAL_BALLOTS_COUNTED', 'VOTE_FOR_HIGHEST_OFFICE', 'VEP', 'VEP_TURNOUT_RATE', 'VAP'): D[c] = num(D[c])
D['numerator_type'] = np.where(D.TOTAL_BALLOTS_COUNTED.notna(), 'TOTAL_BALLOTS_COUNTED', 'VOTE_FOR_HIGHEST_OFFICE_SUBSTITUTE')
D['numerator'] = D.TOTAL_BALLOTS_COUNTED.fillna(D.VOTE_FOR_HIGHEST_OFFICE); D['turnout_vep'] = D.numerator / D.VEP
D['published_rate'] = D.VEP_TURNOUT_RATE / 100; D['election_type'] = np.where(D.YEAR % 4 == 0, 'PRESIDENTIAL', 'MIDTERM')
D = D.sort_values(['YEAR', 'STATE_ABV']); D.to_csv('s7_direct_prepared.csv', index=False)
ST = sorted(D.STATE_ABV.unique()); NS = len(ST); YRS = list(range(2000, 2024)); T = len(YRS); assert NS == 50
def obs_list(drop=()):
    O = {t: [] for t in range(T)}
    for _, r in D[~D.YEAR.isin(drop)].iterrows(): O[r.YEAR - 2000].append((ST.index(r.STATE_ABV), int(r.election_type == 'MIDTERM'), int(r.numerator_type != 'TOTAL_BALLOTS_COUNTED'), r.turnout_vep))
    return O
def unpack(th, spec):
    p = dict(m0=th[0], s0=np.exp(th[1]), qu=np.exp(th[2]), aM=th[3], lM=th[4], tP=np.exp(th[5]), tM=np.exp(th[6]))
    i = 7; p['qm'] = np.exp(th[i]) if spec['national'] else 0.0; i += spec['national']; p['dsub'] = th[i] if spec['sub'] else 0.0; return p
def npar(spec): return 7 + spec['national'] + spec['sub']
def kf(th, spec, O, smooth=False):
    p = unpack(th, spec); n = NS + 1; x = np.zeros(n); x[0] = p['m0']; P = np.diag([0.0] + [p['s0'] ** 2] * NS); Q = np.diag([p['qm']] + [p['qu']] * NS); ll = 0; XF, PF, XP, PP = [], [], [], []
    for t in range(T):
        if t: P = P + Q
        XP.append(x.copy()); PP.append(P.copy())
        for s, mid, sub, y in O[t]:
            a = (p['aM'] if mid else 0.0) + (p['dsub'] if sub else 0.0); l = p['lM'] if mid else 1.0; tau = p['tM'] if mid else p['tP']
            ph = l * (P[:, 0] + P[:, s + 1]); F = l * (ph[0] + ph[s + 1]) + tau ** 2; e = y - a - l * (x[0] + x[s + 1])
            ll += -0.5 * (np.log(2 * np.pi * F) + e * e / F); K = ph / F; x = x + K * e; P = P - np.outer(K, ph)
        XF.append(x.copy()); PF.append(P.copy())
    if not smooth: return ll
    xs, Ps = [None] * T, [None] * T; xs[-1], Ps[-1] = XF[-1], PF[-1]
    for t in range(T - 2, -1, -1):
        J = PF[t] @ np.linalg.pinv(PP[t + 1]); xs[t] = XF[t] + J @ (xs[t + 1] - XP[t + 1]); Ps[t] = PF[t] + J @ (Ps[t + 1] - PP[t + 1]) @ J.T
    S = np.array([xs[t][0] + xs[t][1:] for t in range(T)]); V = np.array([np.diag(Ps[t])[1:] + Ps[t][0, 0] + 2 * Ps[t][0, 1:] for t in range(T)]); return ll, S, V, p
def hess(f, x, h=1e-4):
    k = len(x); H = np.zeros((k, k))
    for i in range(k):
        for j in range(i, k):
            e1, e2 = np.eye(k)[i] * h, np.eye(k)[j] * h; H[i, j] = H[j, i] = (f(x + e1 + e2) - f(x + e1 - e2) - f(x - e1 + e2) + f(x - e1 - e2)) / (4 * h * h)
    return H
def grad(f, x, h=1e-5): return np.array([(f(x + np.eye(len(x))[i] * h) - f(x - np.eye(len(x))[i] * h)) / (2 * h) for i in range(len(x))])
def fit(spec, O, starts=2, tag=''):
    t0 = time.time(); f = lambda th: -kf(th, spec, O); best = None
    for s in range(starts):
        th0 = np.r_[0.58, np.log(0.06), np.log(1e-4), -0.15, 1.0, np.log(0.01), np.log(0.01)] ; th0 = np.r_[th0, [np.log(1e-4)] * spec['national'], [0.0] * spec['sub']]
        if s: th0 = th0 + np.random.normal(0, 0.2, len(th0))
        r = minimize(f, th0, method='L-BFGS-B', options=dict(maxiter=800))
        if best is None or r.fun < best.fun: best = r
    z = best.x
    for _ in range(15):
        g = grad(f, z)
        if np.abs(g).max() < 1e-3: break
        try: z = z - np.linalg.solve(hess(f, z), g)
        except Exception: break
    H = hess(f, z); ev = np.linalg.eigvalsh(H); g = grad(f, z)
    o = dict(tag=tag, ll=-f(z), k=npar(spec), AIC=2 * f(z) + 2 * npar(spec), grad_max=float(np.abs(g).max()), hess_min_eig=float(ev.min()), hess_pd=bool(ev.min() > 0), lbfgs_success=bool(best.success), seconds=round(time.time() - t0, 1))
    print(json.dumps(o, default=float), flush=True); return dict(z=z, H=H, o=o, spec=spec)
def ck(name, fn):
    f = f'ckpt_{name}.pkl'
    if os.path.exists(f): print('loaded', name, flush=True); return pickle.load(open(f, 'rb'))
    v = fn(); pickle.dump(v, open(f, 'wb')); return v
SPECS = {'M1_STATE_RW': dict(national=0, sub=0), 'M2_NATIONAL_STATE_RW': dict(national=1, sub=0), 'M2b_PLUS_NUMERATOR_OFFSET': dict(national=1, sub=1)}
if __name__ == '__main__':
    O = obs_list(); R = {k: ck(k, lambda k=k: fit(SPECS[k], O, tag=k)) for k in SPECS}
    sel = min(R, key=lambda k: R[k]['o']['AIC'] if R[k]['o']['hess_pd'] else 1e9); print('SELECTED', sel, flush=True); json.dump(dict(selected=sel), open('selected.json', 'w'))
    HD = json.load(open('HOLDOUT_DESIGN_PREREGISTERED.json'))['holdouts']
    for h, yrs in HD.items():
        def run(yrs=yrs, h=h):
            Oh = obs_list(yrs); r = fit(SPECS[sel], Oh, starts=1, tag=f'holdout {h}'); _, S, V, p = kf(r['z'], SPECS[sel], Oh, smooth=True); E = []
            for _, x in D[D.YEAR.isin(yrs)].iterrows():
                t = x.YEAR - 2000; s = ST.index(x.STATE_ABV); mid = x.election_type == 'MIDTERM'; sub = x.numerator_type != 'TOTAL_BALLOTS_COUNTED'
                a = (p['aM'] if mid else 0) + (p['dsub'] if sub else 0); l = p['lM'] if mid else 1; tau = p['tM'] if mid else p['tP']
                mu = a + l * S[t, s]; sd = np.sqrt(l * l * V[t, s] + tau ** 2); E.append(dict(state=x.STATE_ABV, err=x.turnout_vep - mu, z=(x.turnout_vep - mu) / sd))
            E = pd.DataFrame(E); return dict(MAE=float(E.err.abs().mean()), RMSE=float(np.sqrt((E.err ** 2).mean())), mean_error=float(E.err.mean()), coverage95=float((E.z.abs() < 1.96).mean()), resid_sd=float(E.err.std()), n=len(E), fit=r['o'])
        res = ck('ho_' + h, run); print(h, {k: v for k, v in res.items() if k != 'fit'}, flush=True)
    print('ALL DONE', flush=True)
