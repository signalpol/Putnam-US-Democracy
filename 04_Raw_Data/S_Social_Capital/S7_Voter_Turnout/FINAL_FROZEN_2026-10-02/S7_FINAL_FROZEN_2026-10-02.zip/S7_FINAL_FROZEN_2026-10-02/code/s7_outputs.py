# Pre-written before holdout results were inspected. Flag rule: MODEL rows get validation_risk=1 if any interior holdout (2004,2010,2016,2018) coverage < 0.90;
# 2023 (one-sided forecast) gets validation_risk=1 if the edge holdout (2000) coverage < 0.90; DIRECT rows with substituted numerator get validation_risk=1.
exec(open('s7_model.py').read().split("if __name__ == '__main__':")[0])
import scipy.stats as ss, hashlib, shutil
sel = json.load(open('selected.json'))['selected']; R = {k: pickle.load(open(f'ckpt_{k}.pkl', 'rb')) for k in SPECS}; O = obs_list()
HO = {h: pickle.load(open(f'ckpt_ho_{h}.pkl', 'rb')) for h in json.load(open('HOLDOUT_DESIGN_PREREGISTERED.json'))['holdouts']}
interior_fail = any(HO[h]['coverage95'] < 0.90 for h in ('H2004_pres', 'H2010_mid', 'H2016_pres', 'H2018_mid')); edge_fail = HO['H2000_edge_pres']['coverage95'] < 0.90
ll, S, V, p = kf(R[sel]['z'], SPECS[sel], O, smooth=True); cov = np.linalg.inv(R[sel]['H']); Sd, Vd = [], []
for zz in np.random.multivariate_normal(R[sel]['z'], cov, 200):
    _, s_, v_, _ = kf(zz, SPECS[sel], O, smooth=True); Sd.append(s_); Vd.append(v_)
TV = np.array(Vd).mean(0) + np.array(Sd).var(0)
Dp = D.set_index(['YEAR', 'STATE_ABV']); fips = {'AL':'01','AK':'02','AZ':'04','AR':'05','CA':'06','CO':'08','CT':'09','DE':'10','FL':'12','GA':'13','HI':'15','ID':'16','IL':'17','IN':'18','IA':'19','KS':'20','KY':'21','LA':'22','ME':'23','MD':'24','MA':'25','MI':'26','MN':'27','MS':'28','MO':'29','MT':'30','NE':'31','NV':'32','NH':'33','NJ':'34','NM':'35','NY':'36','NC':'37','ND':'38','OH':'39','OK':'40','OR':'41','PA':'42','RI':'44','SC':'45','SD':'46','TN':'47','TX':'48','UT':'49','VT':'50','VA':'51','WA':'53','WV':'54','WI':'55','WY':'56'}
rows = []
for t, y in enumerate(YRS):
    for s, st in enumerate(ST):
        if (y, st) in Dp.index:
            r = Dp.loc[(y, st)]; mid = r.election_type == 'MIDTERM'; sub = r.numerator_type != 'TOTAL_BALLOTS_COUNTED'
            a = (p['aM'] if mid else 0) + (p['dsub'] if sub else 0); l = p['lM'] if mid else 1.0; tau = p['tM'] if mid else p['tP']
            est, se = (r.turnout_vep - a) / l, tau / l; ot = 'DIRECT'; et = r.election_type; risk = int(sub); obs = r.turnout_vep; nt = r.numerator_type
        else:
            est, se = S[t, s], np.sqrt(TV[t, s]); ot = 'MODEL_ESTIMATED'; et = 'NO_GENERAL_ELECTION'; obs = np.nan; nt = ''
            risk = int(interior_fail or (y == 2023 and edge_fail))
        rows.append(dict(state=st, state_fips=fips[st], year=y, S7_estimate=est, S7_SE=se, CI_lower=est - 1.96 * se, CI_upper=est + 1.96 * se, observed_turnout_vep=obs, observation_type=ot,
                         direct_observation=int(ot == 'DIRECT'), model_estimated=int(ot != 'DIRECT'), election_type=et, turnout_definition='VEP turnout = TOTAL_BALLOTS_COUNTED/VEP (McDonald, UF Election Lab v1.2)' + ('; numerator = VOTE_FOR_HIGHEST_OFFICE substitute' if nt == 'VOTE_FOR_HIGHEST_OFFICE_SUBSTITUTE' else ''),
                         scale='presidential-equivalent latent participation (S7_estimate); observed_turnout_vep is raw', source='UF Election Lab 1980-2022 General Election Turnout Rates v1.2' if ot == 'DIRECT' else 'MODEL', model=sel,
                         backcast_flag=0, forecast_flag=int(y == 2023), validation_risk=risk, provenance=f'S7F-{y}-{st}'))
F = pd.DataFrame(rows); os.makedirs('pkg', exist_ok=True)
DIR = D[['YEAR', 'STATE', 'STATE_ABV', 'election_type', 'TOTAL_BALLOTS_COUNTED', 'VOTE_FOR_HIGHEST_OFFICE', 'numerator_type', 'numerator', 'VEP', 'VAP', 'turnout_vep', 'published_rate']].rename(columns={'published_rate': 'published_VEP_TURNOUT_RATE'})
mc = pd.DataFrame([dict(model=k, **R[k]['o']) for k in SPECS]); mc['selected'] = mc.model == sel
pp = dict(p); ho = pd.DataFrame([dict(holdout=h, **{k: v for k, v in d.items() if k != 'fit'}, fit_grad=d['fit']['grad_max'], fit_hess_pd=d['fit']['hess_pd']) for h, d in HO.items()])
# validation: national trend & ranking
nat_obs = D.groupby('YEAR').apply(lambda g: (g.numerator.sum() / g.VEP.sum())); nat_lat = pd.Series(S.mean(1), index=YRS)
rk = [dict(year=y, rank_corr_latent_vs_direct=float(ss.spearmanr(F[(F.year == y)].S7_estimate, S[YRS.index(y)])[0])) for y in range(2000, 2023, 2)]
pickle.dump(dict(F=F, DIR=DIR, mc=mc, p=pp, ho=ho, nat_obs=nat_obs, nat_lat=nat_lat, rk=rk, interior_fail=interior_fail, edge_fail=edge_fail), open('outputs.pkl', 'wb'))
print(mc[['model', 'll', 'k', 'AIC', 'grad_max', 'hess_min_eig', 'hess_pd', 'lbfgs_success']].to_string()); print(pp); print(ho.round(4).to_string()); print('flags', interior_fail, edge_fail)
print(pd.DataFrame(rk).rank_corr_latent_vs_direct.describe().round(3).to_dict()); print('rows', len(F), 'direct', F.direct_observation.sum(), 'risk', F.validation_risk.sum())
