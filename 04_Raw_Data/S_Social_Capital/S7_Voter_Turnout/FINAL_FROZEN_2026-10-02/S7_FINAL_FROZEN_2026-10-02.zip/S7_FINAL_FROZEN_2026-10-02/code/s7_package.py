import pickle, pandas as pd, numpy as np, json, os, shutil, hashlib
X = pickle.load(open('outputs.pkl', 'rb')); F, DIR, mc, p, ho = X['F'], X['DIR'], X['mc'], X['p'], X['ho']
P = 'S7_FINAL_FROZEN_2026-10-02'; shutil.rmtree(P, ignore_errors=True); [os.makedirs(f'{P}/{d}') for d in ('code', 'logs', 'source')]
F.to_csv(f'{P}/S7_FINAL_2000_2023.csv', index=False); DIR.to_csv(f'{P}/S7_DIRECT_OBSERVATIONS_FINAL.csv', index=False); mc.to_csv(f'{P}/S7_MODEL_COMPARISON.csv', index=False)
with pd.ExcelWriter(f'{P}/S7_FINAL_2000_2023.xlsx') as w:
    F.to_excel(w, sheet_name='S7_FINAL', index=False); DIR.to_excel(w, sheet_name='DIRECT', index=False); ho.to_excel(w, sheet_name='Holdout', index=False); mc.to_excel(w, sheet_name='Models', index=False)
nat = pd.DataFrame(dict(year=X['nat_obs'].index, national_direct_turnout=X['nat_obs'].values)).merge(pd.DataFrame(dict(year=X['nat_lat'].index, national_latent_mean=X['nat_lat'].values)), how='right')
nat.to_csv(f'{P}/S7_NATIONAL_TREND_CHECK.csv', index=False); ho.to_csv(f'{P}/S7_HOLDOUT_VALIDATION.csv', index=False)
src = pd.DataFrame([dict(source='UF Election Lab / Michael McDonald, 1980-2022 General Election Turnout Rates v1.2', file='Turnout_1980_2022_v1.2.csv', url='https://election.lab.ufl.edu/data-downloads/turnoutdata/Turnout_1980_2022_v1.2.csv', sha256=hashlib.sha256(open('../src/Turnout_1980_2022_v1.2.csv', 'rb').read()).hexdigest(), role='PRIMARY_DIRECT'),
    dict(source='UF Election Lab documentation v1.2', file='Turnout_1980_2022_v1.2_doc.txt', url='https://election.lab.ufl.edu/data-downloads/turnoutdata/Turnout_1980_2022_v1.2_doc.txt', sha256=hashlib.sha256(open('../src/Turnout_1980_2022_v1.2_doc.txt', 'rb').read()).hexdigest(), role='DEFINITIONS'),
    dict(source='Project P06 file S1_P06_UF_VEP_presidential_waves_2000_2020.csv (GitHub)', file='S1_P06_UF_VEP_presidential_waves_2000_2020.csv', url='github signalpol/Putnam-US-Democracy STRICT/P06_TURNOUT/UF_ELECTION_LAB', sha256=hashlib.sha256(open('/tmp/pr/04_Raw_Data/S_Social_Capital/STRICT/P06_TURNOUT/UF_ELECTION_LAB/S1_P06_UF_VEP_presidential_waves_2000_2020.csv', 'rb').read()).hexdigest(), role='CROSS-CHECK: 281/300 identical rates, 19 missing in P06 (ballots not reported)'),
    dict(source='Drive S7_Voter_Turnout_CANONICAL_RAW_v1.csv / v2.csv', file='(not read: 173,750 / 174,933 bytes exceed tool transfer)', url='Drive folder 1P2Ba4Ra2TnOMxSGz9tFCDeirA73ZkU3B', sha256='', role='NOT AUDITED')])
src.to_csv(f'{P}/S7_SOURCE_REGISTRY.csv', index=False)
for f in ['../src/Turnout_1980_2022_v1.2.csv', '../src/Turnout_1980_2022_v1.2_doc.txt', '../src/download_log.txt']: shutil.copy(f, f'{P}/source/')
for f in ['s7_model.py', 's7_outputs.py', 's7_package.py', 'HOLDOUT_DESIGN_PREREGISTERED.json']: shutil.copy(f, f'{P}/code/')
shutil.copy('s7_run.log', f'{P}/logs/')
qa = [('rows', len(F), 1200), ('states', F.state.nunique(), 50), ('years', f'{F.year.min()}-{F.year.max()} ({F.year.nunique()})', '2000-2023 (24)'), ('duplicates', int(F.duplicated(['state', 'year']).sum()), 0),
      ('DC/territories', int((~F.state.isin(DIR.STATE_ABV.unique())).sum()), 0), ('missing S7_estimate', int(F.S7_estimate.isna().sum()), 0), ('missing SE', int(F.S7_SE.isna().sum()), 0),
      ('DIRECT rows (even years)', int(F.direct_observation.sum()), 600), ('MODEL_ESTIMATED rows (odd years)', int(F.model_estimated.sum()), 600),
      ('direct reproduction vs published VEP_TURNOUT_RATE', f"{int((DIR.dropna(subset=['published_VEP_TURNOUT_RATE']).eval('abs(turnout_vep-published_VEP_TURNOUT_RATE)') <= 5e-5 + 1e-12).sum())}/{int(DIR.published_VEP_TURNOUT_RATE.notna().sum())}", 'all within rounding 0.00005'),
      ('numerator substitute rows (highest office)', int((DIR.numerator_type != 'TOTAL_BALLOTS_COUNTED').sum()), 'documented'), ('validation_risk rows', int(F.validation_risk.sum()), 'documented'),
      ('observed_turnout_vep equals direct file', bool(np.allclose(F[F.direct_observation == 1].sort_values(['year', 'state']).observed_turnout_vep.values, DIR.sort_values(['YEAR', 'STATE_ABV']).turnout_vep.values)), True),
      ('interpolation/ffill/bfill', 0, 0), ('backcast rows', int(F.backcast_flag.sum()), 0)]
pd.DataFrame(qa, columns=['check', 'observed', 'expected']).to_csv(f'{P}/S7_QA_FINAL.csv', index=False); print(pd.DataFrame(qa).to_string())
json.dump(dict(params=p, interior_fail=X['interior_fail'], edge_fail=X['edge_fail']), open(f'{P}/logs/s7_selected_params.json', 'w'), indent=1, default=float)
